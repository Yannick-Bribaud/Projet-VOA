package Modele_tsp;
import java.util.ArrayList;
import java.util.List;

public class distance {
	
	public static int sumtotal=Integer.MAX_VALUE;	
	static List<Integer> visitedRouteList = new ArrayList<>();

	public static void distanceminimaltotal(int[][]t, int nbrville) {
	
	for(int k=0;k<nbrville; k++)
	 {
		GreedySolution.findMinRoute(t,k);
   	
		 if(sumtotal>GreedySolution.som)
		 {
			 sumtotal=GreedySolution.som;
			 visitedRouteList =GreedySolution.maliste;
		 }
	 }
}
 
}
