package Modele_tsp;


public class population {
	    
	
		//remplir un tableau avec des valeur r�el ente 0 et 1
	 	public static  double []remplir(double tab[], double tab2[],double n,int nombreVille) {
	    for(int l=0;l<nombreVille;l++)
	    {
	      tab2[l] = tab[l] = Math.random();
	    }
	    return tab;
	  }
	 	
	 	
	 	
	 	//fct qui fait le tri d'un tableau
	 	public static double []tri(double t[],int nbreville){
	    double temp;
	    
	    for (int i = 0; i <nbreville; i++)
	     {
	    	
	      for (int j = i + 1; j < t.length; j++)
	      {
	        if (t[i] > t[j])
	        {
	          temp = t[i];
	          t[i] = t[j];
	          t[j] = temp;
	        }
	    }
	  }
	    return t;
	}
	 	
	 	
	 	public static int[] triVoa(int[] c,int nombreVille){
	 		int temp;
	    for (int i = 0; i <nombreVille; i++)
	    	
	      for (int j = i + 1; j < c.length; j++)
	        if (c[i] > c[j])
	        {
	          temp = c[i];
	          c[i] = c[j];
	          c[j] =  temp;
	        }
	    return c;
	}
	 	
	 	
	 	public static double[] triDouble(double[] matrix,int nombreVille){
	 		
	 		double temp;
	    for (int i = 0; i <nombreVille; i++)
	     {
	      for (int j = i + 1; j < matrix.length; j++)
	      {
	        if (matrix[i] > matrix[j])
	        {
	          temp = matrix[i];
	          matrix[i] = matrix[j];
	          matrix[j] =  temp;
	        }
	      }
	    } 
	    return matrix;
	}
}
	    