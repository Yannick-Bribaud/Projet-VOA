package Modele_tsp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class GreedySolution {
	
		public static String nomv;
		public static ArrayList<String> tab = new ArrayList<String>();
		public static ArrayList<String> tabGreedy = new ArrayList<String>();
		public static ArrayList<String> tabHybridation = new ArrayList<String>();
		public static int som=0;
		public static List<Integer> maliste = new ArrayList<>();
		public static List<Integer> malisteHybrid = new ArrayList<>();
		public static int sizeligne;
		public static double  Tab[],  TAB[];
		public static int tab3[];
		
	
		
	 //cette methode calcul les distances minimal
	 //a chaque fois la ville de depart change
	 public static void findMinRoute(int[][] tsp, int k) 
	    { 
	        int sum = 0;
	        int counter = 0; 
	        int j = 0, i = k; 
	        int min = Integer.MAX_VALUE; 
	       List<Integer> visitedRouteList = new ArrayList<>();
	      
	        sizeligne=tsp[i].length;
	       int[] route = new int[tsp.length]; 
	        
	// l'indice "i" point sur la matrice tant dis que l'indice "j" pointe sue le tableau de la matrice
	        visitedRouteList.add(k); 
	        while (i < tsp.length 
	               && j < sizeligne) { 
	        	
	  // l'indice counter pointe sur le tableau route
	        	// le tableau route contient les indices (j+1) des villes qu'on a visit� 
	            if (counter >= sizeligne - 1) { 
	                break; 
	            } 
	  //la premiere condition c'est pour eviter de prendre la distance entre deux m�me villes
	  // tandi que la deuxi�me condition c'es pour eviter de revisit� la m�me ville
	            if (j != i 
	                && !(visitedRouteList.contains(j))) { 
	                if (tsp[i][j] < min) { 
	                    min = tsp[i][j]; 
	                    route[counter] = j + 1; 
	                } 
	            } 
	            j++; 
	  //ici on le parcour  du tableau de la matrice est termin�
	  // alors on ajoute la distance minimal entre la ville d'indice "i" et l'autre ville d'indice "j"
	  // on ajoute aussi � la liste "visitedRouteList" l'indice de la vile q'on a visit� 
	  //on recommence les m�mes etapes jusqu'a ce que on retrouve la distance minimal des villes  
	            if (j == sizeligne) { 
	                sum += min; 
	                min = Integer.MAX_VALUE; 
	                visitedRouteList.add(route[counter] - 1); 
	                j = 0; 
	                i = route[counter] - 1; 
	                counter++; 
	            } 
	        } 
	       // ici c'est pour retourner � la ville de depart
	        //et ajouter ca distance
	        i = route[counter - 1] - 1; 
	        sum+=tsp[i][k];
	        
	        GreedySolution.som=sum;	 
	        GreedySolution.maliste=visitedRouteList;
	        
	       
	    }
	 
	 
	 public static double [] RouteReal(int nombreVille) {
	       
	       Tab=new double [nombreVille];
	       double []tab2=new double [nombreVille];
	       tab3=new int [nombreVille];
        
	       //remplissage aleatoire
	       Hybride.remplir(Tab, tab2,nombreVille);
	       
		   //classement
		   Hybride.classementDouble(Tab,tab2,tab3,nombreVille);
		 
		return Tab;

	 }
	 
	 
public static void FindMinRoutReal(int [][] tsp, int k,int nombreVille) {
		 
		 	TAB= new double[nombreVille];
		 	int sum = 0; 
	        int counter = 0; 
	        int i=k;

	        List<Integer> visitedRouteList = new ArrayList<Integer>(); 
	 
	        visitedRouteList.add(k); 
	        int[] route = new int[tsp.length]; 
	  
	        while (i < tsp.length) { 
	  
	            // Corner of the Matrix 
	            if (counter >= tsp[i].length - 1) { 
	                break; 
	            } 
	  
	            int j = new Random().nextInt(tsp[i].length);
	            if (j != i 
	                && !(visitedRouteList.contains(j))) { 
	                sum+= tsp[i][j];
	                route[counter]=j;
	                visitedRouteList.add(j);
	                i = j; 
	                counter++; 
	            }
	        } 
	  
	        sum+=tsp[i][visitedRouteList.get(0)];
	         
	        // Started from the node where 
	        // we finished as well. 
	        GreedySolution.som=sum;	 
	        GreedySolution.malisteHybrid=visitedRouteList;
	        
	        for(int ii=0;ii<nombreVille;ii++) {
	        	TAB[ii]= Tab[malisteHybrid.get(ii)];
	        }
	        
	               
	 }
	 

	 
}

