package Modele_tsp;

import java.util.ArrayList;

import java.util.List;
import java.util.Random;
import Controleur.CntrlerHybridation;



public class Hybride {
	

	public static void ajoutGreedyS(double[] c0, double[] c,int [][]matrixV,double [][] matrix, int nombreVille,int TaillePop) {
		
			Random rand = new Random ();
		
			GreedySolution.RouteReal(nombreVille);
			int k=rand.nextInt(nombreVille);
			
			GreedySolution.FindMinRoutReal(CntrlerHybridation.TableauDistanceHybrid,k,nombreVille); 
			
				c[TaillePop-1]=c0[TaillePop-1]=GreedySolution.som;

		
		for(int i1=0;i1<nombreVille;i1++) 
		{
			matrixV[TaillePop-1][i1]=GreedySolution.malisteHybrid.get(i1);
		}
		   
		for(int i1=0; i1<nombreVille;i1++)
		{	
			matrix[CntrlerHybridation.f-1][i1]=GreedySolution.TAB[i1];
		}
		
	}
	
	public static void ajoutGreedyMultiple(double[] c0, double[] c,int [][] matrixV,double [][] matrix,int nbreville,int taillePop) {
		
		Random rand = new Random () ;
		int ii=3;
		List<Integer> couts = new ArrayList<Integer>();

			
			while(ii>0){
				
				GreedySolution.RouteReal(nbreville);
				int k=rand.nextInt(nbreville);				
				GreedySolution.FindMinRoutReal(CntrlerHybridation.TableauDistanceHybrid,k,nbreville); 
				
				if(!couts.contains(GreedySolution.som)) {
				couts.add(GreedySolution.som);
				c[taillePop-ii]=c0[taillePop-ii]=GreedySolution.som;
				
					for(int i1=0; i1<nbreville;i1++) 
						matrix[taillePop-1][i1]=GreedySolution.TAB[i1];
				
				for(int j=0;j<nbreville;j++) 
					matrixV[taillePop-ii][j]=GreedySolution.malisteHybrid.get(j);;
				
					ii--;
			}
				
		}
			
			
}
	
	
	public static void RempAlea(int[][] m,int nombreVille) {
		
		Random rand = new Random (); 
	    for (int n = 0; n < nombreVille; n++) {
	      for (int j = 0; j <=n; j++) {
	    	  if(n==j) {
	    		  m[n][j]=0;}
	    	  	else {
	    	  		m[n][j]=rand.nextInt(99)+1;
	    	  	}
	    	  	}
	    }
	    
	    for(int n=0;n<nombreVille;n++) {
	    	for(int j=0;j<nombreVille;j++) {
	    		if(m[n][j]!=m[j][n])
	    		{
	    			m[n][j]=m[j][n];
	    		}
	    	}
	    }
	    	  
	}
	
	
	
	public static  void rempliralt(int[][]m,int nombreVille) {
		 
		 Random rand = new Random () ; 
		    for (int n = 0; n < nombreVille ; n++) {
		      for (int j = 0; j < nombreVille; j++) {
		    	  if(n==j) {
		    		  m[n][j]=0;
		    	  }else {
		    		  m[n][j] =  rand.nextInt (100);
		    	  }
		        
		      }
		    }
		}
	
	
	 public static  double[] remplir(double tab[], double tab2[],int nombreville) {
		 
			for(int l=0;l<nombreville;l++)
			{
				tab2[l] = tab[l] = Math.random();
			}
				return tab;
	}
	 
	 public static void classementDouble (double[] c,double[] c0 ,int []tab,int n) {
		 
		 List<Integer> TAB = new ArrayList<>();
		 for(int i=0;i<n;++i) {
			   	for(int j=0;j<n;++j) {
			   		if (c[i]==c0[j]&& !TAB.contains(j))
			   		{
			   			TAB.add(j);
			   		}
			   	}
		 }
		 for(int i=0;i<n;i++) {
			 tab[i]=TAB.get(i);
		 }
	 }
	 
	 
	 public static void remplirV(int [][] mat, int [] tab, int f,int nombreVille) {
			for(int i=0;i<nombreVille;i++) {
				mat[f][i]=tab[i];
			}
		}
	 
	 
	 public static void r�cupmat (int [] tab,double []t,int nombreVille) {
		 for( int g=0;g<nombreVille-1;g++)
		 {
		 	t[g] = CntrlerHybridation.TableauDistanceHybrid[tab[g]][tab[g+1]];
		 }
		t[nombreVille-1]=CntrlerHybridation.TableauDistanceHybrid[tab[nombreVille-1]][tab[0]];
	 }
	 
	 public static void r�cupmatInt (int [] tab,int []t,int nombreVille) {
		 for( int g=0;g<nombreVille-1;g++)
		 {
		 	t[g] = CntrlerHybridation.TableauDistanceHybrid[tab[g]][tab[g+1]];
		 }
		t[nombreVille-1]=CntrlerHybridation.TableauDistanceHybrid[tab[nombreVille-1]][tab[0]];
	 }
	 
	 
	 public static double somd1tab(double []t,int nombreVille) {
		   double  somme=0;
		   double   [] c = new double[nombreVille];
	      for(int r=0;r<nombreVille;r++) {
	          somme = somme + t[r];
	          c[r]=somme;
	      }
	      return somme;
	   }
	 
	 public static double somd1tabInt(int []t,int nombreVille) {
		   double  somme=0;
		   double   [] c = new double[nombreVille];
	      for(int r=0;r<nombreVille;r++) {
	          somme = somme + t[r];
	          c[r]=somme;
	      }
	      return somme;
	   }
	 
	 
	 public static int BestMin(double[] c, int[][] matrixsol,int nombreVille, int taillePop) {
			int minimum=(int)c[0];
			int jj = 0;
				for(int i = 1; i <taillePop; i++){
				         if(c[i] <= minimum)  {
				        	 minimum =(int)c[i];
				            jj=i;
				         }
				         if(CntrlerHybridation.best> minimum) {
				        	 CntrlerHybridation.best=minimum;
				        	 CntrlerHybridation.indB=jj;
				        	 
				        	 for(int k=0;k<nombreVille;k++) {
				        		 CntrlerHybridation.best1[k]=matrixsol[CntrlerHybridation.indB][k];
				       }
				   }
				}  
				
				return CntrlerHybridation.best;		
		}
	 
	 
	 public static void classement (double []tab1,double[]tab2 ,int []tab,int n) {
		 
		 List<Integer> TAB = new ArrayList<>();
		 for(int i=0;i<n;++i) {
			   	for(int j=0;j<n;++j) {
			   		if (tab1[i]==tab2[j])
			   			TAB.add(j);
			   	}
		 }
		 for(int i=0;i<n;i++) {
			 tab[i]=TAB.get(i);
		 }
	 }
	 
	 
	 public static void inverse(double [] tab){
		 
			double temp;
	 for (int i = 0, j = tab.length-1; i < tab.length-2; i++, j--)
	 {
		   temp = tab[i];
		   tab[i] = tab[j];
		   tab[j] = temp;
	 }
	 
 }
	 
	 
	 public static void copitab(double [] matrix, double [][]matrix2, int [] index, int i,int nombreVille) {
		 
		 for(int k=0; k<nombreVille; k++) {
			 
			 matrix[k]=matrix2[index[i]][k];
		 }	
	}
	 
	 
	 public static void antivirus(double []t, double val,int nombreVille) {
			
			int y=new Random().nextInt(nombreVille);		
				if(y>val)
				{
					CntrlerHybridation.v=1;	
				}
			}
	 
	 
	 public static void exploitation(double [] c, int nombreR, int x) {
		  double [] tab4= new double [nombreR];
		
			if(x>=nombreR) {
				
	        for(int i=x-1,j=0;j<nombreR;i--,j++) {
				  
				 tab4[j]=c[i];  	 
			  }
	        for(int i=x-1, j=nombreR-1; j>=0 ; i--,j--) {
	        	c[i]=tab4[j];
	        }
			  }
			else{
			  for(int i=x+1,j=0; j<nombreR;i++,j++) {
				  
				  tab4[j]=c[i]; 
			}
			  for(int i=x+1, j=nombreR-1; j>=0;i++,j--) {
				  
				  c[i]=tab4[j];
			  }
		 }
	}
	 
	 
	 public static void stockSol(int  [][] MatSol, int [] best1, int ge, int nbreVille) {
		 
			for(int v=0; v<nbreVille;v++)
			{
				   MatSol[ge][v]=best1[v];
			}
		}
	 
	 public static void TotalMin( int[] tabmin,int NombreGeneration) {
			
			CntrlerHybridation.min=CntrlerHybridation.tabmin[0];
			
			for(int k = 1;k<NombreGeneration;k++ ) {
				
				if(CntrlerHybridation.min>tabmin[k]) 
					{
					CntrlerHybridation.min=tabmin[k];
					CntrlerHybridation.ind=k;
					CntrlerHybridation.best=CntrlerHybridation.min;
					}
			}
			
		}
	
	
	
}