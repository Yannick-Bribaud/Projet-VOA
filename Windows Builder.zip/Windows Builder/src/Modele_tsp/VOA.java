package Modele_tsp;

import java.util.ArrayList;


import java.util.List;
import java.util.Random;
import Controleur.VoaCntrler;
import vue.VoaInterface;

public class VOA {
	
	
	VoaInterface vue = new VoaInterface();
		
		static int nombreVille ;
		int nombreGeneration ;
		static int nombrePopulation; 
	    static int nombreR;
		
	public VOA(VoaInterface vue) {
		
		this.vue=vue;
		
		nombreVille = Integer.parseInt(vue.getTextFieldNombreVilleVOA().getText());
		nombreGeneration = Integer.parseInt(vue.getTextFieldNombreGenerationsVOA().getText());
	 	nombrePopulation = Integer.parseInt(vue.getTextFieldNombrePopulationVOA().getText());
	 	nombreR = Integer.parseInt(vue.getTextFieldNbreRVOA().getText());	
	 	
	}
	
		
		public static void inverse(double [] tab){
			double temp;
	 for (int i = 0, j = tab.length-1; i < tab.length-2; i++, j--)
	 {
	   temp = tab[i];
	   tab[i] = tab[j];
	   tab[j] = temp;
	 }
	 
	}

	public static double mind1tab(double []tab) {
		
		double min=tab[0];
			for(int i = 0; i <tab.length; i++){
			         if(tab[i] < min) {
			           min =tab[i];}
			         }
			 return min;
	}
	  public static double somd1tab(double []t,int nombreVille) {
		   double  somme=0;
		   double   [] c = new double[nombreVille];
	      for(int r=0;r<nombreVille;r++) {
	          somme = somme + t[r];
	          c[r]=somme;
	      }
	      return somme;
	   }
	  
	  public static int somd1tabInt(int []t,int nombreVille) {
		   int  somme=0;
		   double   [] c = new double[nombreVille];
	      for(int r=0;r<nombreVille;r++) {
	          somme = somme + t[r];
	          c[r]=somme;
	      }
	      return somme;
	   }
	
	  public static  double[] remplir (double tab[], double tab2[],int nombreVille) {
			for(int l=0;l<nombreVille;l++)
			tab2[l] = tab[l] = Math.random();
			return tab;
			}
	  
		public static  void rempliralt(int[][]m) {
		 
		 Random rand = new Random () ; 
		    for (int n = 0; n < nombreVille ; n++) {
		      for (int j = 0; j < nombreVille; j++) {
		    	  if(n==j) {
		    		  m[n][j]=0;
		    	  }else {
		    		  m[n][j] =  rand.nextInt (15);
		    	  }
		        
		      }
		    }
		}
		
		
		public static void exploitation(double [] c, int nombreR, int x) {
			
			  double [] tab4= new double [nombreR];
			
				if(x>=nombreR) {
		        for(int i=x-1,j=0;j<nombreR;i--,j++) {
					  
					 tab4[j]=c[i];  	 
				  }
		        
		        for(int i=x-1, j=nombreR-1; j>=0 ; i--,j--) {
		        	c[i]=tab4[j];
		        }
		        
				  }
				else{
				  for(int i=x+1,j=0; j<nombreR;i++,j++) {
					  
					  tab4[j]=c[i]; 
				}
				  for(int i=x+1, j=nombreR-1; j>=0;i++,j--) {
					  
					  c[i]=tab4[j];
				  }
				  }
		}
		
		
		
		public static void classement (double []tab1,double[]tab2 ,int []tab,int n) {
			 
			 List<Integer> TAB = new ArrayList<>();
			 for(int i=0;i<n;++i) {
				   	for(int j=0;j<n;++j) {
				   		if (tab1[i]==tab2[j])
				   			TAB.add(j);
				   	}
			 }
			 for(int i=0;i<n;i++) {
				 tab[i]=TAB.get(i);
			 }
		 }
		
		public static void classement (int[] c,int[] c0 ,int []tab,int n) {
			 
			 List<Integer> TAB = new ArrayList<>();
			 for(int i=0;i<n;++i) {
				   	for(int j=0;j<n;++j) {
				   		if (c[i]==c0[j]&& !TAB.contains(j))
				   			TAB.add(j);
				   	}
			 }
			 for(int i=0;i<n;i++) {
				 tab[i]=TAB.get(i);
			 }
		 }
		
		public static void r�cupmat (int [] tab,int[] t,int nombreVille) {
			 for( int g=0;g<nombreVille-1;g++)
			 	t[g] = VoaCntrler.a[tab[g]][tab[g+1]];
			t[nombreVille-1]=VoaCntrler.a[tab[nombreVille-1]][tab[0]];
		 }
		
		
		public static void classementDouble (double[] c,double[] c0 ,int []tab,int n) {
			 
			 List<Integer> TAB = new ArrayList<>();
			 for(int i=0;i<n;++i) {
				   	for(int j=0;j<n;++j) {
				   		if (c[i]==c0[j]&& !TAB.contains(j))
				   			TAB.add(j);
				   	}
			 }
			 for(int i=0;i<n;i++) {
				 tab[i]=TAB.get(i);
			 }
		 }
		
		
		public static void RempAlea(int[][] m) {
			Random rand = new Random () ; 
		    for (int n = 0; n < nombreVille; n++) {
		      for (int j = 0; j <=n; j++) {
		    	  if(n==j) 
		    		  m[n][j]=0;
		    	  	else {
		    	  		m[n][j]=rand.nextInt(15+1)+1;
		    	  	}
		    	  	}
		    }
		    
		    for(int n=0;n<nombreVille;n++) {
		    	for(int j=0;j<nombreVille;j++) {
		    		if(m[n][j]!=m[j][n])
		    			m[n][j]=m[j][n];
		    	}
		    }
		    	  
		}
		
		public static int BestMin(int[] c, int[][] matrixsol,int TaillePop) {
			int minimum=c[0];
			int jj = 0;
				for(int i = 1; i <TaillePop; i++){
				         if(c[i] <= minimum)  {
				        	 minimum =c[i];
				            jj=i;
				         }
				         if(VoaCntrler.best> minimum) {
				        	 VoaCntrler.best=minimum;
				        	 VoaCntrler.indB=jj;
				        	 
				        	 for(int k=0;k<nombreVille;k++) {
				        		 VoaCntrler.best1[k]=matrixsol[VoaCntrler.indB][k];
				       }
				   }
				}  
				
				return VoaCntrler.best;		
		}
		
		
		
		public static void copitab(double [] matrix, double [][]matrix2, int [] index, int i,int nombreVille) {
			 for(int k=0; k<nombreVille; k++) {
				 matrix[k]=matrix2[index[i]][k];
			 }	
		}
		
		public static void remplirV(int [][] mat, int [] tab, int f,int nombreVille) {
			for(int i=0;i<nombreVille;i++) {
				mat[f][i]=tab[i];
			}
		}
		
		
		
		public static void TotalMin( int[] tabmin,int NombreGeneration) {
			
			VoaCntrler.min=VoaCntrler.tabmin[0];
			for(int k = 1;k<NombreGeneration;k++ ) {
				if(VoaCntrler.min>tabmin[k]) 
					{
					VoaCntrler.min=tabmin[k];
					VoaCntrler.ind=k;
					VoaCntrler.best=VoaCntrler.min;
					}
			}
			
		}
		
		
		public static void stockSol(int  [][] MatSol, int [] best1, int ge ,int nombreVille) {
			for(int v=0; v<nombreVille;v++) 
				   MatSol[ge][v]=best1[v];
		}
		
		
		public static void antivirus(double []t, double val,int nombreVille) {
			
			int y=new Random().nextInt(nombreVille);		
				if(y>val)
					VoaCntrler.v=1;
			}
		

		

}
		
	