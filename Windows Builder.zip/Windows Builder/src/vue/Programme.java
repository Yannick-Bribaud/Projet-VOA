package vue;
import Controleur.PrincipaleInterfaceCntrler;


public class Programme {

	public static void main(String[] args) {
	
		
		PrincipaleInterface vue = new PrincipaleInterface();
		PrincipaleInterfaceCntrler controleur = new PrincipaleInterfaceCntrler(vue);
		controleur.run();
			 
		
	}

}
