package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Dimension;
import javax.swing.border.LineBorder;

public class GreedySolutionInterface extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldGreedyNombreVille;
	private JRadioButton rdbtnManuelle;
	private JRadioButton rdbtnAleatoire;
	private JButton btnGreedyOK;
	private JRadioButton rdbtnAsymetrie;
	private JRadioButton rdbtnSymetrie;
	
	
	public GreedySolutionInterface() {
		setResizable(false);
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(new Dimension(474, 204));
		setMinimumSize(new Dimension(474, 204));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		this.setLocationRelativeTo(null);
		
		rdbtnManuelle = new JRadioButton("Manuelle");
		rdbtnManuelle.setBackground(Color.WHITE);
		rdbtnManuelle.setFont(new Font("Rockwell", Font.BOLD, 16));
		rdbtnManuelle.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnManuelle.setBounds(150, 65, 119, 29);
		panel.add(rdbtnManuelle);
		
		rdbtnAleatoire = new JRadioButton("Al\u00E9atoire");
		rdbtnAleatoire.setBackground(Color.WHITE);
		rdbtnAleatoire.setFont(new Font("Rockwell", Font.BOLD, 16));
		rdbtnAleatoire.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnAleatoire.setBounds(150, 105, 117, 29);
		panel.add(rdbtnAleatoire);
		
		rdbtnManuelle.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnManuelle.isSelected())
				{
					rdbtnAleatoire.setSelected(false);
				}	
			}	
		});
		
		rdbtnAleatoire.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnAleatoire.isSelected())
				{
					rdbtnManuelle.setSelected(false);
				}
			}	
		});
		
		textFieldGreedyNombreVille = new JTextField();
		textFieldGreedyNombreVille.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldGreedyNombreVille.setFont(new Font("Rockwell", Font.BOLD, 17));
		textFieldGreedyNombreVille.setForeground(Color.WHITE);
		textFieldGreedyNombreVille.setBackground(Color.BLACK);
		textFieldGreedyNombreVille.setBounds(328, 65, 96, 26);
		panel.add(textFieldGreedyNombreVille);
		textFieldGreedyNombreVille.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nombre de villes");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel.setBounds(290, 33, 152, 27);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		panel_1.setBounds(-14, 0, 481, 29);
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Greedy Solution");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1);
		
		btnGreedyOK = new JButton("Valider");
		btnGreedyOK.setBorder(new LineBorder(new Color(0, 128, 0)));
		btnGreedyOK.setForeground(Color.WHITE);
		btnGreedyOK.setBackground(new Color(0, 0, 128));
		btnGreedyOK.setFont(new Font("Rockwell", Font.BOLD, 15));
		btnGreedyOK.setBounds(328, 103, 96, 29);
		panel.add(btnGreedyOK);
		
		rdbtnAsymetrie = new JRadioButton("Asymetrie");
		rdbtnAsymetrie.setFont(new Font("Rockwell", Font.BOLD, 16));
		rdbtnAsymetrie.setBackground(Color.WHITE);
		rdbtnAsymetrie.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnAsymetrie.setBounds(10, 67, 127, 29);
		panel.add(rdbtnAsymetrie);
		
		rdbtnSymetrie = new JRadioButton("Symetrie");
		rdbtnSymetrie.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnSymetrie.setFont(new Font("Rockwell", Font.BOLD, 16));
		rdbtnSymetrie.setBackground(Color.WHITE);
		rdbtnSymetrie.setBounds(10, 105, 115, 29);
		panel.add(rdbtnSymetrie);
		
		rdbtnAsymetrie.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnAsymetrie.isSelected())
				{
					rdbtnSymetrie.setSelected(false);
				}
				
			}
		});
		
		
		
		rdbtnSymetrie.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnSymetrie.isSelected())
				{
					rdbtnAsymetrie.setSelected(false);
				}
				
			}
		});
		
		JLabel lblNewLabel_2 = new JLabel("Type && Mode Remplissage");
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(-4, 33, 273, 29);
		panel.add(lblNewLabel_2);
	}


	
	
	public JRadioButton getRdbtnAsymetrie() {
		return rdbtnAsymetrie;
	}

	public void setRdbtnAsymetrie(JRadioButton rdbtnAsymetrie) {
		this.rdbtnAsymetrie = rdbtnAsymetrie;
	}


	public JRadioButton getRdbtnSymetrie() {
		return rdbtnSymetrie;
	}


	public void setRdbtnSymetrie(JRadioButton rdbtnSymetrie) {
		this.rdbtnSymetrie = rdbtnSymetrie;
	}


	public JTextField getTextFieldGreedyNombreVille() {
		return textFieldGreedyNombreVille;
	}

	public void setTextFieldGreedyNombreVille(JTextField textFieldGreedyNombreVille) {
		this.textFieldGreedyNombreVille = textFieldGreedyNombreVille;
	}

	public JRadioButton getRdbtnManuelle() {
		return rdbtnManuelle;
	}

	public void setRdbtnManuelle(JRadioButton rdbtnManuelle) {
		this.rdbtnManuelle = rdbtnManuelle;
	}

	public JRadioButton getRdbtnAleatoire() {
		return rdbtnAleatoire;
	}

	public void setRdbtnAleatoire(JRadioButton rdbtnAleatoire) {
		this.rdbtnAleatoire = rdbtnAleatoire;
	}

	public JButton getBtnGreedyOK() {
		return btnGreedyOK;
	}

	public void setBtnGreedyOK(JButton btnGreedyOK) {
		this.btnGreedyOK = btnGreedyOK;
	}
	
	public void run()
	{
		this.setVisible(true);
	}

	public void EcouteurBtnOKgreedy(ActionListener actionListener) {
		btnGreedyOK.addActionListener(actionListener);
		
	}

	public void Message(String message) {
 JOptionPane.showMessageDialog(null, message,"Exception"
			,JOptionPane.WARNING_MESSAGE);
		
	}
}
