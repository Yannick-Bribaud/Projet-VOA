package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.Dimension;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;

public class HybridationInterface extends JFrame {
	
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldVille;
	private JTextField textFieldGeneration;
	private JTextField textFieldNbrePopulation;
	private JTextField textFieldNbreVirus;
	private JTextField textFieldRayon;
	private JTable TableVilleDistance;
	private JRadioButton rdbtnSymetrique;
	private JRadioButton rdbtnManuelle;
	private JRadioButton rdbtnAsymetrique;
	private JRadioButton rdbtnAleatoire;
	private JList<String> list;
	private JButton btnHybridation;
	private JTabbedPane tabbedPane;
	private JPanel panel_3;
	private JLabel lblNewLabel_7;
	private JTextField textFieldNbreSolutionGreedy;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JRadioButton rdbtnHbrydSimple;
	private JRadioButton rdbtnHbrydMultiple;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	
	
	public HybridationInterface() {
		setResizable(false);
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(new Dimension(567, 625));
		setMinimumSize(new Dimension(552, 587));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		rdbtnSymetrique = new JRadioButton("Symetrique");
		rdbtnSymetrique.setBackground(Color.WHITE);
		rdbtnSymetrique.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnSymetrique.setBounds(24, 77, 122, 24);
		panel.add(rdbtnSymetrique);
		
		rdbtnAsymetrique = new JRadioButton("Asymetrique");
		rdbtnAsymetrique.setBackground(Color.WHITE);
		rdbtnAsymetrique.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnAsymetrique.setBounds(24, 109, 131, 24);
		panel.add(rdbtnAsymetrique);
		
		rdbtnSymetrique.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnSymetrique.isSelected())
				{
					rdbtnAsymetrique.setSelected(false);
				}	
			}
		});
		
		rdbtnAsymetrique.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnAsymetrique.isSelected())
				{
					rdbtnSymetrique.setSelected(false);
				}
				
			}
		});
		
		
		JLabel lblNewLabel = new JLabel("Type Remplissage Distance");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel.setBounds(-15, 45, 252, 20);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Mode Remplissage Distance");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_1.setBounds(-15, 165, 260, 20);
		panel.add(lblNewLabel_1);
		
		rdbtnAleatoire = new JRadioButton("Al\u00E9atoire");
		rdbtnAleatoire.setBackground(Color.WHITE);
		rdbtnAleatoire.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnAleatoire.setBounds(24, 197, 122, 24);
		panel.add(rdbtnAleatoire);
		
		rdbtnManuelle = new JRadioButton("Manuelle");
		rdbtnManuelle.setBackground(Color.WHITE);
		rdbtnManuelle.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnManuelle.setBounds(24, 229, 104, 24);
		panel.add(rdbtnManuelle);
		
		rdbtnAleatoire.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnAleatoire.isSelected())
				{
					rdbtnManuelle.setSelected(false);
				}
			}
		});
		
		rdbtnManuelle.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnManuelle.isSelected())
				{
				  rdbtnAleatoire.setSelected(false);
				}	
			}
		});
		
		
		textFieldVille = new JTextField();
		textFieldVille.setForeground(Color.WHITE);
		textFieldVille.setBackground(Color.BLACK);
		textFieldVille.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldVille.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldVille.setBounds(426, 66, 104, 25);
		panel.add(textFieldVille);
		textFieldVille.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Nombre Ville");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_2.setBounds(291, 70, 137, 20);
		panel.add(lblNewLabel_2);
		
		textFieldGeneration = new JTextField();
		textFieldGeneration.setForeground(Color.WHITE);
		textFieldGeneration.setBackground(Color.BLACK);
		textFieldGeneration.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldGeneration.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldGeneration.setBounds(426, 108, 104, 25);
		panel.add(textFieldGeneration);
		textFieldGeneration.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel(" Nombre Generation");
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(273, 112, 155, 20);
		panel.add(lblNewLabel_3);
		
		textFieldNbrePopulation = new JTextField();
		textFieldNbrePopulation.setForeground(Color.WHITE);
		textFieldNbrePopulation.setBackground(Color.BLACK);
		textFieldNbrePopulation.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbrePopulation.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNbrePopulation.setBounds(426, 149, 104, 26);
		panel.add(textFieldNbrePopulation);
		textFieldNbrePopulation.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Taille Population");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_4.setBounds(291, 152, 137, 20);
		panel.add(lblNewLabel_4);
		
		textFieldNbreVirus = new JTextField();
		textFieldNbreVirus.setForeground(Color.WHITE);
		textFieldNbreVirus.setBackground(Color.BLACK);
		textFieldNbreVirus.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNbreVirus.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbreVirus.setBounds(426, 197, 104, 26);
		panel.add(textFieldNbreVirus);
		textFieldNbreVirus.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Nombre Virus Fort");
		lblNewLabel_5.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(268, 200, 160, 20);
		panel.add(lblNewLabel_5);
		
		textFieldRayon = new JTextField();
		textFieldRayon.setForeground(Color.WHITE);
		textFieldRayon.setBackground(Color.BLACK);
		textFieldRayon.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldRayon.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldRayon.setBounds(426, 243, 104, 26);
		panel.add(textFieldRayon);
		textFieldRayon.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Rayon");
		lblNewLabel_6.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(316, 245, 112, 20);
		panel.add(lblNewLabel_6);
		
		btnHybridation = new JButton("Valider");
		btnHybridation.setForeground(Color.WHITE);
		btnHybridation.setBorder(new LineBorder(new Color(0, 0, 128)));
		btnHybridation.setBackground(new Color(0, 0, 128));
		btnHybridation.setFont(new Font("Rockwell", Font.BOLD, 18));
		btnHybridation.setBounds(316, 337, 167, 35);
		panel.add(btnHybridation);
		
		 tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		 tabbedPane.setFont(new Font("Rockwell", Font.BOLD, 16));
		 tabbedPane.setForeground(Color.WHITE);
		 tabbedPane.setBackground(new Color(0, 0, 128));
		 tabbedPane.setBounds(73, 390, 410, 172);
		panel.add(tabbedPane);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		tabbedPane.addTab("Liste des villes", null, panel_1, null);
		panel_1.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 0, 405, 140);
		panel_1.add(scrollPane_1);
		
		list = new JList<String>();
		scrollPane_1.setViewportView(list);
		list.setSelectionBackground(Color.WHITE);
		list.setForeground(Color.WHITE);
		list.setFont(new Font("Rockwell", Font.BOLD, 20));
		list.setBackground(Color.BLACK);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 128));
		tabbedPane.addTab("Table des distances", null, panel_2, null);
		panel_2.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 405, 140);
		panel_2.add(scrollPane);
		
		TableVilleDistance = new JTable();
		scrollPane.setViewportView(TableVilleDistance);
		TableVilleDistance.setSelectionForeground(Color.BLACK);
		TableVilleDistance.setSelectionBackground(Color.BLUE);
		TableVilleDistance.setGridColor(Color.WHITE);
		TableVilleDistance.setFont(new Font("Rockwell", Font.BOLD, 17));
		TableVilleDistance.setForeground(Color.WHITE);
		TableVilleDistance.setBackground(Color.BLACK);
		TableVilleDistance.setShowHorizontalLines(false);
		TableVilleDistance.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Ville-D\u00E9part", "Ville-Arriv\u00E9e", "Distance"
			}
		));
		TableVilleDistance.getColumnModel().getColumn(0).setPreferredWidth(118);
		TableVilleDistance.getColumnModel().getColumn(1).setPreferredWidth(108);
		TableVilleDistance.getColumnModel().getColumn(2).setPreferredWidth(107);
		
		DefaultTableCellRenderer Myrender = new DefaultTableCellRenderer();
		Myrender.setHorizontalAlignment(JLabel.CENTER);
		
		for(int i=0; i<3; i++)
		{
			TableVilleDistance.getColumnModel().getColumn(i).setCellRenderer(Myrender);
		}
		
		JTableHeader Theader = TableVilleDistance.getTableHeader();
		Theader.setBackground(new Color(0, 0, 128));
		Theader.setForeground(new Color(249, 246, 246));
		Theader.setFont(new Font("Tahome", Font.BOLD,15));
		
		panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 0, 128));
		panel_3.setBounds(-15, 0, 575, 29);
		panel.add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		lblNewLabel_7 = new JLabel("HYBRIDATION");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Rockwell", Font.BOLD, 20));
		panel_3.add(lblNewLabel_7, BorderLayout.CENTER);
		
		textFieldNbreSolutionGreedy = new JTextField();
		textFieldNbreSolutionGreedy.setForeground(Color.WHITE);
		textFieldNbreSolutionGreedy.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldNbreSolutionGreedy.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbreSolutionGreedy.setBackground(Color.BLACK);
		textFieldNbreSolutionGreedy.setBounds(426, 285, 104, 26);
		panel.add(textFieldNbreSolutionGreedy);
		textFieldNbreSolutionGreedy.setColumns(10);
		
		lblNewLabel_8 = new JLabel("Nombre solution Greedy");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_8.setBounds(237, 287, 191, 20);
		panel.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("Type Hybridation");
		lblNewLabel_9.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setBounds(0, 273, 147, 20);
		panel.add(lblNewLabel_9);
		
		rdbtnHbrydSimple = new JRadioButton("Simple");
		rdbtnHbrydSimple.setBackground(Color.WHITE);
		rdbtnHbrydSimple.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnHbrydSimple.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnHbrydSimple.setBounds(11, 305, 99, 29);
		panel.add(rdbtnHbrydSimple);
		
		rdbtnHbrydMultiple = new JRadioButton("Multiple");
		rdbtnHbrydMultiple.setBackground(Color.WHITE);
		rdbtnHbrydMultiple.setFont(new Font("Rockwell", Font.BOLD, 14));
		rdbtnHbrydMultiple.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnHbrydMultiple.setBounds(20, 340, 93, 29);
		panel.add(rdbtnHbrydMultiple);
		
		
		rdbtnHbrydSimple.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnHbrydSimple.isSelected())
				{
					rdbtnHbrydMultiple.setSelected(false);
				}	
			}
		});
		
		rdbtnHbrydMultiple.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnHbrydMultiple.isSelected())
				{
					rdbtnHbrydSimple.setSelected(false);
				}	
			}
		});
		
		this.setLocationRelativeTo(null);
	}


	
	
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}

	public void setTabbedPane(JTabbedPane tabbedPane) {
		this.tabbedPane = tabbedPane;
	}

	public JTextField getTextFieldNbreSolutionGreedy() {
		return textFieldNbreSolutionGreedy;
	}


	public void setTextFieldNbreSolutionGreedy(JTextField textFieldNbreSolutionGreedy) {
		this.textFieldNbreSolutionGreedy = textFieldNbreSolutionGreedy;
	}

	public JRadioButton getRdbtnHbrydSimple() {
		return rdbtnHbrydSimple;
	}


	public void setRdbtnHbrydSimple(JRadioButton rdbtnHbrydSimple) {
		this.rdbtnHbrydSimple = rdbtnHbrydSimple;
	}


	public JRadioButton getRdbtnHbrydMultiple() {
		return rdbtnHbrydMultiple;
	}


	public void setRdbtnHbrydMultiple(JRadioButton rdbtnHbrydMultiple) {
		this.rdbtnHbrydMultiple = rdbtnHbrydMultiple;
	}


	public JTextField getTextFieldVille() {
		return textFieldVille;
	}

	public void setTextFieldVille(JTextField textFieldVille) {
		this.textFieldVille = textFieldVille;
	}

	public JTextField getTextFieldGeneration() {
		return textFieldGeneration;
	}

	public void setTextFieldGeneration(JTextField textFieldGeneration) {
		this.textFieldGeneration = textFieldGeneration;
	}

	public JTextField getTextFieldNbrePopulation() {
		return textFieldNbrePopulation;
	}

	public void setTextFieldNbrePopulation(JTextField textFieldNbrePopulation) {
		this.textFieldNbrePopulation = textFieldNbrePopulation;
	}

	public JTextField getTextFieldNbreVirus() {
		return textFieldNbreVirus;
	}

	public void setTextFieldNbreVirus(JTextField textFieldNbreVirus) {
		this.textFieldNbreVirus = textFieldNbreVirus;
	}

	public JTextField getTextFieldRayon() {
		return textFieldRayon;
	}

	public void setTextFieldRayon(JTextField textFieldRayon) {
		this.textFieldRayon = textFieldRayon;
	}

	public JTable getTableVilleDistance() {
		return TableVilleDistance;
	}

	public void setTableVilleDistance(JTable tableVilleDistance) {
		TableVilleDistance = tableVilleDistance;
	}

	public JRadioButton getRdbtnSymetrique() {
		return rdbtnSymetrique;
	}

	public void setRdbtnSymetrique(JRadioButton rdbtnSymetrique) {
		this.rdbtnSymetrique = rdbtnSymetrique;
	}

	public JRadioButton getRdbtnManuelle() {
		return rdbtnManuelle;
	}

	public void setRdbtnManuelle(JRadioButton rdbtnManuelle) {
		this.rdbtnManuelle = rdbtnManuelle;
	}

	public JRadioButton getRdbtnAsymetrique() {
		return rdbtnAsymetrique;
	}

	public void setRdbtnAsymetrique(JRadioButton rdbtnAsymetrique) {
		this.rdbtnAsymetrique = rdbtnAsymetrique;
	}

	public JRadioButton getRdbtnAleatoire() {
		return rdbtnAleatoire;
	}

	public void setRdbtnAleatoire(JRadioButton rdbtnAleatoire) {
		this.rdbtnAleatoire = rdbtnAleatoire;
	}

	public JList<String> getList() {
		return list;
	}

	public void setList(JList<String> list) {
		this.list = list;
	}

	public JButton getBtnHybridationSimple() {
		return btnHybridation;
	}

	public void setBtnHybridationSimple(JButton btnHybridationSimple) {
		this.btnHybridation = btnHybridationSimple;
	}

	public void run() {
		this.setVisible(true);	
	}

	public void EcouteurBtnValider(ActionListener actionListener) {
		btnHybridation.addActionListener(actionListener);
	}


	public void Message(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Exception"
				,JOptionPane.WARNING_MESSAGE);	
	}
	
	
}
