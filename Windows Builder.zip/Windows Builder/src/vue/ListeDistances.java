package vue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class ListeDistances extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldDistanceVilles;
	private JButton btnAddDistance;
	private JLabel lblAfficheVille_1;
	private JLabel lblAfficheVille_2;
	
	public ListeDistances() {
		
		setResizable(false);
		getContentPane().setBackground(new Color(0, 0, 128));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setMinimumSize(new Dimension(460, 165));
		setSize(new Dimension(460, 165));
		
		getContentPane().setLayout(null);
		textFieldDistanceVilles = new JTextField();
		textFieldDistanceVilles.setBackground(Color.BLACK);
		textFieldDistanceVilles.setForeground(Color.WHITE);
		textFieldDistanceVilles.setFont(new Font("Rockwell", Font.BOLD, 14));
		textFieldDistanceVilles.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldDistanceVilles.setBounds(56, 65, 160, 26);
		getContentPane().add(textFieldDistanceVilles);
		textFieldDistanceVilles.setColumns(10);
		this.setLocationRelativeTo(null);
		
		btnAddDistance = new JButton("Valider");
		btnAddDistance.setForeground(new Color(0, 0, 128));
		btnAddDistance.setBorder(new LineBorder(new Color(0, 128, 0)));
		btnAddDistance.setBackground(Color.WHITE);
		btnAddDistance.setFont(new Font("Rockwell", Font.BOLD, 17));
		btnAddDistance.setBounds(251, 64, 130, 26);
		getContentPane().add(btnAddDistance);
		
		JLabel lblNewLabel = new JLabel("DISTANCE ENTRE VILLES");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 458, 20);
		getContentPane().add(lblNewLabel);
		
		 lblAfficheVille_1 = new JLabel("New label");
		 lblAfficheVille_1.setForeground(Color.WHITE);
		 lblAfficheVille_1.setFont(new Font("Rockwell", Font.BOLD, 18));
		 lblAfficheVille_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblAfficheVille_1.setBounds(10, 30, 136, 20);
		getContentPane().add(lblAfficheVille_1);
		
		lblAfficheVille_2 = new JLabel("New label");
		lblAfficheVille_2.setForeground(Color.WHITE);
		lblAfficheVille_2.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblAfficheVille_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblAfficheVille_2.setBounds(290, 30, 168, 20);
		getContentPane().add(lblAfficheVille_2);
		
		JLabel lblNewLabel_3 = new JLabel("&&");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 19));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(201, 30, 74, 20);
		getContentPane().add(lblNewLabel_3);
		
	}

	
	
	public JTextField getTextFieldDistanceVilles() {
		
		return textFieldDistanceVilles;
	}

	public void setTextFieldDistanceVilles(JTextField textFieldDistanceVilles) {
		
		this.textFieldDistanceVilles = textFieldDistanceVilles;
	}

	public JButton getBtnAddDistance() {
		
		return btnAddDistance;
	}

	public void setBtnAddDistance(JButton btnAddDistance) {
		
		this.btnAddDistance = btnAddDistance;
	}

	public JLabel getLblAfficheVille_1() {
		
		return lblAfficheVille_1;
	}

	public void setLblAfficheVille_1(JLabel lblAfficheVille_1) {
		
		this.lblAfficheVille_1 = lblAfficheVille_1;
	}

	public JLabel getLblAfficheVille_2() {
		
		return lblAfficheVille_2;
	}

	public void setLblAfficheVille_2(JLabel lblAfficheVille_2) {
		this.lblAfficheVille_2 = lblAfficheVille_2;
	}

	public void ecouteurBtnOk(ActionListener actionListener) {
		
		btnAddDistance.addActionListener(actionListener);	
	}

	public void Message(String message) {
		JOptionPane.showMessageDialog(null, message,"Champs vide/Mauvais format de donnee"
				,JOptionPane.WARNING_MESSAGE);	
		
	}
	public void run() {
		this.setVisible(true);
		
	}

	public void fermerFenetre() {
		this.dispose();	
	}

	public void EcouteurBtnOk(ActionListener actionListener) {
		btnAddDistance.addActionListener(actionListener);
		
	}

	public void EcouteurBtnAdd(ActionListener actionListener) {
		btnAddDistance.addActionListener(actionListener);	
	}

	public void Messages(String message) {
		
	JOptionPane.showMessageDialog(null, message,"Exception"
			,JOptionPane.WARNING_MESSAGE);		
	}
	
	

	
	

}
