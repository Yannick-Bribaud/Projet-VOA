package vue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.LineBorder;

public class VoaInterface extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldNombreVilleVOA;
	private JTextField textFieldNombreGenerationsVOA;
	private JTextField textFieldNombrePopulationVOA;
	private JTextField textFieldNbreRVOA;
	private JRadioButton rdbtnManuelle;
	private JRadioButton rdbtnAlatoire;
	private JButton btnVOAoK;
	private JList<String> listVoa ;
	private JScrollPane scrollPane;
	private JTable Mytable;
	private JRadioButton rdbtnAsymetrie;
	private JRadioButton rdbtnSymetrie;
	private JLabel lblNewLabel_1;
	private JTextField textFieldNbreVirus;

	
	public VoaInterface() {
		setResizable(false);
		setMinimumSize(new Dimension(493, 565));
		getContentPane().setBackground(Color.WHITE);
		setSize(new Dimension(493, 565));
		initialize();
	}

 
	private void initialize() {
		this.setBounds(100, 100, 493, 515);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.getContentPane().setLayout(null);
		this.setLocationRelativeTo(null);
		
	    rdbtnAlatoire = new JRadioButton("Al\u00E9atoire");
	    rdbtnAlatoire.setBackground(Color.WHITE);
	    rdbtnAlatoire.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnAlatoire.setFont(new Font("Rockwell", Font.BOLD, 15));
		rdbtnAlatoire.setBounds(11, 63, 107, 28);
		this.getContentPane().add(rdbtnAlatoire);
		
	    rdbtnManuelle = new JRadioButton("Manuelle");
	    rdbtnManuelle.setBackground(Color.WHITE);
	    rdbtnManuelle.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnManuelle.setFont(new Font("Rockwell", Font.BOLD, 15));
		rdbtnManuelle.setBounds(3, 94, 124, 26);
		this.getContentPane().add(rdbtnManuelle);
		
		rdbtnAlatoire.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnAlatoire.isSelected())
				{
					rdbtnManuelle.setSelected(false);
				}	
			}
		});
		
		rdbtnManuelle.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnManuelle.isSelected())
				{
					rdbtnAlatoire.setSelected(false);
				}	
			}
		});
		
		JLabel lblNombreDeVille = new JLabel("Nombre de ville");
		lblNombreDeVille.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombreDeVille.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNombreDeVille.setBounds(226, 65, 143, 22);
		this.getContentPane().add(lblNombreDeVille);
		
		textFieldNombreVilleVOA = new JTextField();
		textFieldNombreVilleVOA.setBackground(Color.BLACK);
		textFieldNombreVilleVOA.setForeground(Color.WHITE);
		textFieldNombreVilleVOA.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldNombreVilleVOA.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNombreVilleVOA.setBounds(365, 63, 95, 24);
		this.getContentPane().add(textFieldNombreVilleVOA);
		textFieldNombreVilleVOA.setColumns(10);
		
		JLabel lblNombreDeGnration = new JLabel("Nombre de G\u00E9n\u00E9ration");
		lblNombreDeGnration.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNombreDeGnration.setBounds(199, 104, 170, 22);
		this.getContentPane().add(lblNombreDeGnration);
		
		textFieldNombreGenerationsVOA = new JTextField();
		textFieldNombreGenerationsVOA.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNombreGenerationsVOA.setBackground(Color.BLACK);
		textFieldNombreGenerationsVOA.setForeground(Color.WHITE);
		textFieldNombreGenerationsVOA.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldNombreGenerationsVOA.setBounds(365, 102, 95, 24);
		this.getContentPane().add(textFieldNombreGenerationsVOA);
		textFieldNombreGenerationsVOA.setColumns(10);
		
		JLabel lblNombreDePopulation = new JLabel("Nombre De Population ");
		lblNombreDePopulation.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombreDePopulation.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNombreDePopulation.setBounds(199, 144, 170, 21);
		this.getContentPane().add(lblNombreDePopulation);
		
		textFieldNombrePopulationVOA = new JTextField();
		textFieldNombrePopulationVOA.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNombrePopulationVOA.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldNombrePopulationVOA.setForeground(Color.WHITE);
		textFieldNombrePopulationVOA.setBackground(Color.BLACK);
		textFieldNombrePopulationVOA.setBounds(365, 141, 95, 24);
		this.getContentPane().add(textFieldNombrePopulationVOA);
		textFieldNombrePopulationVOA.setColumns(10);
		
		textFieldNbreRVOA = new JTextField();
		textFieldNbreRVOA.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbreRVOA.setForeground(Color.WHITE);
		textFieldNbreRVOA.setBackground(Color.BLACK);
		textFieldNbreRVOA.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldNbreRVOA.setBounds(365, 180, 95, 24);
		this.getContentPane().add(textFieldNbreRVOA);
		textFieldNbreRVOA.setColumns(10);
		
		JLabel lblNombreDeR = new JLabel("Nombre de R");
		lblNombreDeR.setHorizontalAlignment(SwingConstants.CENTER);
		lblNombreDeR.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNombreDeR.setBounds(245, 183, 124, 21);
		this.getContentPane().add(lblNombreDeR);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 236, 124, 113);
		getContentPane().add(scrollPane);
		
		listVoa = new JList<String>();
		listVoa.setFont(new Font("Rockwell", Font.BOLD, 17));
		listVoa.setForeground(Color.WHITE);
		listVoa.setBackground(new Color(0, 0, 128));
		scrollPane.setViewportView(listVoa);
		
		btnVOAoK = new JButton("Valider");
		btnVOAoK.setForeground(Color.WHITE);
		btnVOAoK.setBorder(new LineBorder(new Color(0, 0, 255)));
		btnVOAoK.setBackground(new Color(0, 0, 128));
		btnVOAoK.setFont(new Font("Rockwell", Font.BOLD, 17));
		btnVOAoK.setBounds(279, 266, 107, 35);
		this.getContentPane().add(btnVOAoK);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(24, 365, 441, 135);
		getContentPane().add(scrollPane_1);
		
		Mytable = new JTable();
		Mytable.setShowHorizontalLines(false);
		Mytable.setFont(new Font("Rockwell", Font.BOLD, 18));
		Mytable.setBackground(new Color(0, 0, 128));
		Mytable.setForeground(Color.WHITE);
		Mytable.setGridColor(Color.WHITE);
		Mytable.setRowHeight(20);
		Mytable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Ville 1", "Ville 2", "Distance"
			}
		));
		
		DefaultTableCellRenderer Myrender = new DefaultTableCellRenderer();
		Myrender.setHorizontalAlignment(JLabel.CENTER);
		
		for(int i=0; i<3; i++)
		{
			Mytable.getColumnModel().getColumn(i).setCellRenderer(Myrender);
		}
		
		JTableHeader Theader = Mytable.getTableHeader();
		Theader.setBackground(new Color(0, 0, 128));
		Theader.setForeground(new Color(249, 246, 246));
		Theader.setFont(new Font("Tahome", Font.BOLD,15));
		scrollPane_1.setViewportView(Mytable);
		
		JLabel lblNewLabel = new JLabel("Liste des Villes");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 13));
		lblNewLabel.setBounds(25, 214, 121, 20);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(-14, 0, 513, 26);
		getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("V.O.A  SOLUTION");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_2, BorderLayout.CENTER);
		
		rdbtnAsymetrie = new JRadioButton("Asym\u00E9trie");
		rdbtnAsymetrie.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnAsymetrie.setBackground(Color.WHITE);
		rdbtnAsymetrie.setFont(new Font("Rockwell", Font.BOLD, 15));
		rdbtnAsymetrie.setBounds(3, 125, 130, 29);
		getContentPane().add(rdbtnAsymetrie);
		
		rdbtnSymetrie = new JRadioButton("Symetrie");
		rdbtnSymetrie.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnSymetrie.setBackground(Color.WHITE);
		rdbtnSymetrie.setFont(new Font("Rockwell", Font.BOLD, 15));
		rdbtnSymetrie.setBounds(3, 158, 120, 29);
		getContentPane().add(rdbtnSymetrie);
		
		
		rdbtnAsymetrie.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(rdbtnAsymetrie.isSelected())
				{
					rdbtnSymetrie.setSelected(false);
				}
				
			}
		});
		
		rdbtnSymetrie.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rdbtnSymetrie.isSelected())
				{
					rdbtnAsymetrie.setSelected(false);
				}
				
			}
		});
		
		lblNewLabel_1 = new JLabel("Type && Mode Remplissage");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_1.setBounds(3, 35, 219, 20);
		getContentPane().add(lblNewLabel_1);
		
		textFieldNbreVirus = new JTextField();
		textFieldNbreVirus.setForeground(Color.WHITE);
		textFieldNbreVirus.setBackground(Color.BLACK);
		textFieldNbreVirus.setFont(new Font("Rockwell", Font.BOLD, 16));
		textFieldNbreVirus.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNbreVirus.setBounds(365, 220, 95, 24);
		getContentPane().add(textFieldNbreVirus);
		textFieldNbreVirus.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Nombre Virus");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 14));
		lblNewLabel_3.setBounds(245, 220, 113, 20);
		getContentPane().add(lblNewLabel_3);
	}


	
	public JList<String> getListVoa() {
		return listVoa;
	}


	public void setListVoa(JList<String> listVoa) {
		this.listVoa = listVoa;
	}


	public JTextField getTextFieldNbreVirus() {
		return textFieldNbreVirus;
	}


	public void setTextFieldNbreVirus(JTextField textFieldNbreVirus) {
		this.textFieldNbreVirus = textFieldNbreVirus;
	}


	public JRadioButton getRdbtnAsymetrie() {
		return rdbtnAsymetrie;
	}

	public void setRdbtnAsymetrie(JRadioButton rdbtnAsymetrie) {
		this.rdbtnAsymetrie = rdbtnAsymetrie;
	}

	public JRadioButton getRdbtnSymetrie() {
		return rdbtnSymetrie;
	}

	public void setRdbtnSymetrie(JRadioButton rdbtnSymetrie) {
		this.rdbtnSymetrie = rdbtnSymetrie;
	}

	public JTable getMytable() {
		return Mytable;
	}

	public void setMytable(JTable mytable) {
		Mytable = mytable;
	}

	public JList<String> getList() {
		return listVoa;
	}

	public void setList(JList<String> list) {
		this.listVoa = list;
	}

	public JTextField getTextFieldNombreVilleVOA() {
		return textFieldNombreVilleVOA;
	}

	public void setTextFieldNombreVilleVOA(JTextField textFieldNombreVilleVOA) {
		this.textFieldNombreVilleVOA = textFieldNombreVilleVOA;
	}

	public JTextField getTextFieldNombreGenerationsVOA() {
		return textFieldNombreGenerationsVOA;
	}

	public void setTextFieldNombreGenerationsVOA(JTextField textFieldNombreGenerationsVOA) {
		this.textFieldNombreGenerationsVOA = textFieldNombreGenerationsVOA;
	}

	public JTextField getTextFieldNombrePopulationVOA() {
		return textFieldNombrePopulationVOA;
	}

	public void setTextFieldNombrePopulationVOA(JTextField textFieldNombrePopulationVOA) {
		this.textFieldNombrePopulationVOA = textFieldNombrePopulationVOA;
	}

	public JTextField getTextFieldNbreRVOA() {
		return textFieldNbreRVOA;
	}

	public void setTextFieldNbreRVOA(JTextField textFieldNbreRVOA) {
		this.textFieldNbreRVOA = textFieldNbreRVOA;
	}

	public JRadioButton getRdbtnManuelle() {
		return rdbtnManuelle;
	}

	public void setRdbtnManuelle(JRadioButton rdbtnManuelle) {
		this.rdbtnManuelle = rdbtnManuelle;
	}

	public JRadioButton getRdbtnAlatoire() {
		return rdbtnAlatoire;
	}

	public void setRdbtnAlatoire(JRadioButton rdbtnAlatoire) {
		this.rdbtnAlatoire = rdbtnAlatoire;
	}

	public JButton getBtnVOAoK() {
		return btnVOAoK;
	}

	public void setBtnVOAoK(JButton btnVOAoK) {
		this.btnVOAoK = btnVOAoK;
	}

	public void run() {
		this.setVisible(true);
		
	}

	public void Message(String message) {
		JOptionPane.showMessageDialog(null, message,"Exception"
				,JOptionPane.WARNING_MESSAGE);	
	}
	
	public void addEcouteurBtnOK(ActionListener actionListener) {
		btnVOAoK.addActionListener(actionListener);
		
	}

	public void fermer() {
		this.dispose();
		
	}
}
