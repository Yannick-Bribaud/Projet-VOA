package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class AfficheDistanceVoa extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldDistanceAffiche;
	private JTable tableListeDistanceMinimale;
	
	
	public AfficheDistanceVoa() {
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setMinimumSize(new Dimension(10, 10));
		
		setSize(new Dimension(450, 235));
		setMinimumSize(new Dimension(450, 235));
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setFont(new Font("Rockwell", Font.BOLD, 18));
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Distance Minimale");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel.setBounds(5, 47, 146, 20);
		panel.add(lblNewLabel);
		
		textFieldDistanceAffiche = new JTextField();
		textFieldDistanceAffiche.setBackground(Color.BLACK);
		textFieldDistanceAffiche.setSelectionColor(new Color(30, 144, 255));
		textFieldDistanceAffiche.setForeground(Color.WHITE);
		textFieldDistanceAffiche.setEnabled(false);
		textFieldDistanceAffiche.setFont(new Font("Rockwell", Font.BOLD, 18));
		textFieldDistanceAffiche.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldDistanceAffiche.setBounds(5, 77, 156, 26);
		panel.add(textFieldDistanceAffiche);
		textFieldDistanceAffiche.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Court Chemin \u00E0 Emprunter");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 15));
		lblNewLabel_1.setBounds(207, 47, 203, 20);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		panel_1.setBounds(0, 0, 435, 26);
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("RESULTATS VOA");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setFont(new Font("Rockwell", Font.BOLD, 18));
		scrollPane.setBounds(204, 78, 209, 100);
		panel.add(scrollPane);
		
		tableListeDistanceMinimale = new JTable();
		tableListeDistanceMinimale.setShowHorizontalLines(false);
		tableListeDistanceMinimale.setShowVerticalLines(false);
		tableListeDistanceMinimale.setRowHeight(20);
		tableListeDistanceMinimale.setGridColor(Color.BLACK);
		tableListeDistanceMinimale.setForeground(Color.WHITE);
		tableListeDistanceMinimale.setFont(new Font("Rockwell", Font.BOLD, 18));
		tableListeDistanceMinimale.setBackground(new Color(0, 0, 128));
		tableListeDistanceMinimale.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Court Chemin"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JTableHeader Theader = tableListeDistanceMinimale.getTableHeader();
		Theader.setBackground(new Color(4, 26, 76));
		Theader.setForeground(new Color(249, 246, 246));
		Theader.setFont(new Font("Tahome", Font.BOLD,15));
		
		scrollPane.setViewportView(tableListeDistanceMinimale);
		this.setLocationRelativeTo(null);
	}
	
	
	public JTable getTableListeDistanceMinimale() {
		return tableListeDistanceMinimale;
	}

	public void setTableListeDistanceMinimale(JTable tableListeDistanceMinimale) {
		this.tableListeDistanceMinimale = tableListeDistanceMinimale;
	}

	public JTextField getTextFieldDistanceAffiche() {
		return textFieldDistanceAffiche;
	}

	public void setTextFieldDistanceAffiche(JTextField textFieldDistanceAffiche) {
		this.textFieldDistanceAffiche = textFieldDistanceAffiche;
	}

	public void run() {
		this.setVisible(true);
		
	}
}
