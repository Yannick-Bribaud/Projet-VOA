package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.Dimension;

public class ResultatHybrid extends JFrame {
	
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldDistanceMin;
	private JTable tableChemin;
	
	public ResultatHybrid() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		
		
		setMinimumSize(new Dimension(500, 300));
		setSize(new Dimension(500, 300));
		
		JPanel panel = new JPanel();
		panel.setSize(new Dimension(501, 300));
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(0, 0, 128));
		tabbedPane.setForeground(Color.WHITE);
		tabbedPane.setFont(new Font("Rockwell", Font.BOLD, 16));
		tabbedPane.setBounds(72, 60, 337, 160);
		panel.add(tabbedPane);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		tabbedPane.addTab("Distance Minimale", null, panel_1, null);
		panel_1.setLayout(null);
		
		textFieldDistanceMin = new JTextField();
		textFieldDistanceMin.setBackground(Color.BLACK);
		textFieldDistanceMin.setForeground(Color.WHITE);
		textFieldDistanceMin.setFont(new Font("Rockwell", Font.BOLD, 18));
		textFieldDistanceMin.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldDistanceMin.setBounds(84, 46, 167, 32);
		panel_1.add(textFieldDistanceMin);
		textFieldDistanceMin.setColumns(10);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(84, 78, 167, 17);
		panel_1.add(panel_4);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.BLACK);
		tabbedPane.addTab("Court Chemin", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 5, 310, 115);
		panel_3.add(scrollPane);
		
		tableChemin = new JTable();
		tableChemin.setFont(new Font("Rockwell", Font.BOLD, 16));
		tableChemin.setForeground(Color.WHITE);
		tableChemin.setBackground(new Color(0, 0, 128));
		tableChemin.setShowHorizontalLines(false);
		tableChemin.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Court Chemin"
			}
		) {
			private static final long serialVersionUID = 1L;
			
			boolean[] columnEditables = new boolean[] {
				false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		
		
		
		DefaultTableCellRenderer Myrender = new DefaultTableCellRenderer();
		Myrender.setHorizontalAlignment(JLabel.CENTER);
		
		for(int i=0; i<1; i++)
		{
			tableChemin.getColumnModel().getColumn(i).setCellRenderer(Myrender);
		}
		
		
		JTableHeader Theader = tableChemin.getTableHeader();
		Theader.setBackground(new Color(0, 0, 128));
		Theader.setForeground(new Color(249, 246, 246));
		Theader.setFont(new Font("Tahome", Font.BOLD,15));
		scrollPane.setViewportView(tableChemin);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 128));
		panel_2.setBounds(-18, 0, 515, 38);
		panel.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("RESULTAT HYBRIDE");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		panel_2.add(lblNewLabel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		
	}

	
	
	public JTextField getTextFieldDistanceMin() {
		return textFieldDistanceMin;
	}

	public void setTextFieldDistanceMin(JTextField textFieldDistanceMin) {
		this.textFieldDistanceMin = textFieldDistanceMin;
	}

	public JTable getTableChemin() {
		return tableChemin;
	}

	public void setTableChemin(JTable tableChemin) {
		this.tableChemin = tableChemin;
	}


	public void run() {
		this.setVisible(true);
	}
}
