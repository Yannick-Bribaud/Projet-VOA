package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.Dimension;
import javax.swing.JTabbedPane;

public class ResultatGreedy extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JTextField textFieldAfficheDistanceMinimal;
	private JList<String> listVilles;
	private JTable tableDistanceVille;
	private JTable tableDistanceMinimale;
	private JTabbedPane tabbedPane;
	
	
	public ResultatGreedy() {
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
		setMinimumSize(new Dimension(498, 360));
		setSize(new Dimension(498, 360));
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		
		tableDistanceVille = new JTable();
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(0, 0, 128));
		tabbedPane.setForeground(Color.WHITE);
		tabbedPane.setFont(new Font("Rockwell", Font.BOLD, 18));
		tableDistanceMinimale = new JTable();
		
			
		textFieldAfficheDistanceMinimal = new JTextField();
		textFieldAfficheDistanceMinimal.setBackground(Color.BLACK);
		textFieldAfficheDistanceMinimal.setForeground(Color.WHITE);
		textFieldAfficheDistanceMinimal.setFont(new Font("Rockwell", Font.BOLD, 20));
		textFieldAfficheDistanceMinimal.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldAfficheDistanceMinimal.setEditable(false);
		textFieldAfficheDistanceMinimal.setBounds(153, 71, 160, 30);
		panel.add(textFieldAfficheDistanceMinimal);
		textFieldAfficheDistanceMinimal.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Distance Minimale");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(143, 42, 180, 20);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		panel_1.setBounds(-18, 0, 567, 26);
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("RESULTATS GREEDY");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1, BorderLayout.CENTER);
		
		getContentPane().add(panel, BorderLayout.CENTER);
		
	   
		tabbedPane.setBounds(10, 130, 455, 165);
		panel.add(tabbedPane);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		tabbedPane.addTab("Liste Ville", null, panel_2, null);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 1, 450, 127);
		panel_2.add(scrollPane);
		
		listVilles = new JList<String>();
		scrollPane.setViewportView(listVilles);
		listVilles.setFont(new Font("Rockwell", Font.BOLD, 14));
		listVilles.setForeground(Color.WHITE);
		listVilles.setBackground(new Color(25, 25, 112));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.WHITE);
		tabbedPane.addTab("Table Distances", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBackground(new Color(0, 0, 128));
		scrollPane_3.setBounds(1, 1, 449, 125);
		panel_3.add(scrollPane_3);
		
		
		tableDistanceVille.setShowHorizontalLines(false);
		tableDistanceVille.setForeground(Color.WHITE);
		tableDistanceVille.setFont(new Font("Rockwell", Font.BOLD, 15));
		tableDistanceVille.setBackground(new Color(0, 0, 128));
		scrollPane_3.setViewportView(tableDistanceVille);
		tableDistanceVille.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Ville-D\u00E9part", "Ville-Arriv\u00E9e", "Distances"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.BLACK);
		tabbedPane.addTab("Table Chemin", null, panel_4, null);
		panel_4.setLayout(null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(28, 15, 396, 100);
		panel_4.add(scrollPane_4);
		
		
		tableDistanceMinimale.setGridColor(Color.BLACK);
		tableDistanceMinimale.setShowHorizontalLines(false);
		tableDistanceMinimale.setForeground(Color.WHITE);
		tableDistanceMinimale.setFont(new Font("Rockwell", Font.BOLD, 18));
		tableDistanceMinimale.setBackground(new Color(0, 0, 128));
		scrollPane_4.setViewportView(tableDistanceMinimale);
		tableDistanceMinimale.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Court Chemin"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
				false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableDistanceVille.getColumnModel().getColumn(2).setPreferredWidth(97);
		
		DefaultTableCellRenderer Myrender = new DefaultTableCellRenderer();
		Myrender.setHorizontalAlignment(JLabel.CENTER);
		
		for(int i=0; i<3; i++)
		{
			tableDistanceVille.getColumnModel().getColumn(i).setCellRenderer(Myrender);
		}
		
		JTableHeader Theader = tableDistanceVille.getTableHeader();
		Theader.setBackground(new Color(0, 0, 128));
		Theader.setForeground(new Color(249, 246, 246));
		Theader.setFont(new Font("Tahome", Font.BOLD,15));
		
		DefaultTableCellRenderer Myrenders = new DefaultTableCellRenderer();
		Myrenders.setHorizontalAlignment(JLabel.CENTER);
		
		for(int i=0; i<1; i++)
		{
			tableDistanceMinimale.getColumnModel().getColumn(i).setCellRenderer(Myrender);
		}
		
		JTableHeader Theaders = tableDistanceMinimale.getTableHeader();
		Theaders.setBackground(new Color(0, 0, 128));
		Theaders.setForeground(new Color(249, 246, 246));
		Theaders.setFont(new Font("Tahome", Font.BOLD,15));
		 
		this.setLocationRelativeTo(null);
		
	}
	
	

	public JList<String> getListVilles() {
		return listVilles;
	}

	public void setListVilles(JList<String> listVilles) {
		this.listVilles = listVilles;
	}

	public JTable getTableDistanceVille() {
		return tableDistanceVille;
	}

	public void setTableDistanceVille(JTable tableDistanceVille) {
		this.tableDistanceVille = tableDistanceVille;
	}

	public JTable getTableDistanceMinimale() {
		return tableDistanceMinimale;
	}

	public void setTableDistanceMinimale(JTable tableDistanceMinimale) {
		this.tableDistanceMinimale = tableDistanceMinimale;
	}

	public JTextField getTextFieldAfficheDistanceMinimal() {
		return textFieldAfficheDistanceMinimal;
	}

	public void setTextFieldAfficheDistanceMinimal(JTextField textFieldAfficheDistanceMinimal) {
		this.textFieldAfficheDistanceMinimal = textFieldAfficheDistanceMinimal;
	}

	public void run() {
		this.setVisible(true);	
	}
}
