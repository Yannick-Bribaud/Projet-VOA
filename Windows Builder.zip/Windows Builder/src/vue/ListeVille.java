package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class ListeVille extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private JTextField textFieldListeVille;
	private JLabel lblAfficheNumVille;
	private JButton btnAddVille;
	
	public ListeVille() {
		
		setResizable(false);
		setSize(new Dimension(450, 150));
		this.setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setMinimumSize(new Dimension(450, 150));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Listes des villes");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 2, 428, 28);
		panel.add(lblNewLabel);
		
		textFieldListeVille = new JTextField();
		textFieldListeVille.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldListeVille.setBackground(Color.BLACK);
		textFieldListeVille.setFont(new Font("Rockwell", Font.BOLD, 15));
		textFieldListeVille.setForeground(Color.WHITE);
		textFieldListeVille.setBounds(137, 46, 159, 29);
		panel.add(textFieldListeVille);
		textFieldListeVille.setColumns(10);
		
		btnAddVille = new JButton("Valider");
		btnAddVille.setForeground(new Color(0, 0, 128));
		btnAddVille.setBorder(new LineBorder(new Color(0, 128, 0)));
		btnAddVille.setBackground(Color.WHITE);
		btnAddVille.setFont(new Font("Rockwell", Font.BOLD, 18));
		btnAddVille.setBounds(315, 46, 98, 30);
		panel.add(btnAddVille);
		
		JLabel VilleNum = new JLabel("Ville N\u00B0");
		VilleNum.setForeground(Color.WHITE);
		VilleNum.setHorizontalAlignment(SwingConstants.CENTER);
		VilleNum.setFont(new Font("Rockwell", Font.BOLD, 16));
		VilleNum.setBounds(0, 45, 98, 26);
		panel.add(VilleNum);
		
		lblAfficheNumVille = new JLabel("..");
		lblAfficheNumVille.setForeground(Color.WHITE);
		lblAfficheNumVille.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAfficheNumVille.setHorizontalAlignment(SwingConstants.CENTER);
		lblAfficheNumVille.setBounds(83, 50, 31, 20);
		panel.add(lblAfficheNumVille);
		
	}
	
	
	public JButton getBtnAddVille() {
		return btnAddVille;
	}

	public void setBtnAddVille(JButton btnAddVille) {
		this.btnAddVille = btnAddVille;
	}

	public JTextField getTextFieldListeVille() {
		return textFieldListeVille;
	}

	public void setTextFieldListeVille(JTextField textFieldListeVille) {
		this.textFieldListeVille = textFieldListeVille;
	}

	public JLabel getLblAfficheNumVille() {
		return lblAfficheNumVille;
	}

	public void setLblAfficheNumVille(JLabel lblAfficheNumVille) {
		this.lblAfficheNumVille = lblAfficheNumVille;
	}

	public void ecouteurBtnOk(ActionListener actionListener) {
		
		btnAddVille.addActionListener(actionListener);
	}


	public void run() {
	 this.setVisible(true);	
	}

	public void Message(String message) {
		JOptionPane.showMessageDialog(null, message,"Champs vide/Mauvais format de donnee"
				,JOptionPane.WARNING_MESSAGE);	
	}

	public void fermer() {
		this.dispose();
	}

	public void EcouteurOkGreedy(ActionListener actionListener) {
		btnAddVille.addActionListener(actionListener);	
	}


	public void Messages(String message) {
		JOptionPane.showMessageDialog(null, message,"Exception"
				,JOptionPane.WARNING_MESSAGE);	
	}


	public void EcouteurBtnValider(ActionListener actionListener) {
		btnAddVille.addActionListener(actionListener);	
		
	}

	public void Messag(String message) {
		
		JOptionPane.showMessageDialog(null, message,"Exception"
				,JOptionPane.WARNING_MESSAGE);	
		
	}
	
  

	
}
