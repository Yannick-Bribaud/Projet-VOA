package vue;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class PrincipaleInterface  extends JFrame{

	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings("unused")
	private ImageIcon iconPhoto;
	@SuppressWarnings("unused")
	private JLabel imageLBL;
	
	private JButton btnGreedySolution;
	private JButton btnVoa;
	private JButton btnHybridation;
	
	public PrincipaleInterface() {
		setResizable(false);
		setSize(new Dimension(442, 355));
		initialize();
	}

	
	private void initialize() {
		
		this.setTitle("\r\n");
		this.getContentPane().setForeground(Color.BLUE);
		this.setBounds(100, 100, 450, 355);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(null);
		this.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(0, 0, 438, 57);
		getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("PROJET");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1, BorderLayout.NORTH);
		
		JLabel lblNewLabel_2 = new JLabel("PROBLEME DU VOYAGEUR DE COMMERCE");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Rockwell", Font.BOLD, 18));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_2, BorderLayout.SOUTH);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(-6, 57, 444, 258);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		btnGreedySolution = new JButton("GREEDY SOLUTION");
		btnGreedySolution.setForeground(Color.WHITE);
		btnGreedySolution.setBorder(new LineBorder(new Color(0, 0, 255)));
		btnGreedySolution.setBackground(new Color(0, 0, 128));
		btnGreedySolution.setBounds(24, 200, 120, 35);
		panel_1.add(btnGreedySolution);
		btnGreedySolution.setFont(new Font("Rockwell", Font.BOLD, 11));
		
		btnVoa = new JButton("V.O.A  SOLUTION");
		btnVoa.setForeground(Color.WHITE);
		btnVoa.setBorder(new LineBorder(new Color(0, 0, 255)));
		btnVoa.setBackground(new Color(0, 0, 128));
		btnVoa.setBounds(159, 200, 120, 35);
		panel_1.add(btnVoa);
		btnVoa.setFont(new Font("Rockwell", Font.BOLD, 12));
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(PrincipaleInterface.class.getResource("/images/gps.jpg")));
		lblNewLabel.setBounds(25, 20, 394, 163);
		panel_1.add(lblNewLabel);
		
		btnHybridation = new JButton("HYBRIDATION");
		btnHybridation.setForeground(Color.WHITE);
		btnHybridation.setBorder(new LineBorder(new Color(0, 0, 255)));
		btnHybridation.setBackground(new Color(0, 0, 128));
		btnHybridation.setFont(new Font("Rockwell", Font.BOLD, 12));
		btnHybridation.setBounds(294, 201, 125, 35);
		panel_1.add(btnHybridation);
		this.setVisible(true);
		
	}
	
	
	
	public JButton getBtnHybridation() {
		return btnHybridation;
	}

	public void setBtnHybridation(JButton btnHybridation) {
		this.btnHybridation = btnHybridation;
	}

	public JButton getBtnGreedySolution() {
		return btnGreedySolution;
	}

	public void setBtnGreedySolution(JButton btnGreedySolution) {
		this.btnGreedySolution = btnGreedySolution;
	}

	public JButton getBtnVoa() {
		return btnVoa;
	}

	public void setBtnVoa(JButton btnVoa) {
		this.btnVoa = btnVoa;
	}
	
	public void EcouteurBtnGreedySolution(ActionListener actionListener) {
		btnGreedySolution.addActionListener(actionListener);
	}

	public void EcouteurBtnVoa(ActionListener actionListener) {
		btnVoa.addActionListener(actionListener);
	}
	
	public void run() {
		this.setVisible(true);	
	}

	public void EcouteurBtnHybride(ActionListener actionListener) {
		btnHybridation.addActionListener(actionListener);	
	}
}
