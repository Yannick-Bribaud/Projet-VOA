package Controleur;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;
import Modele_tsp.GreedySolution;
import Modele_tsp.VOA;
import vue.AfficheDistanceVoa;
import vue.ListeDistances;
import vue.VoaInterface;


public class CntrlerListeDistances {
	
	ListeDistances vue;
	VoaInterface vue_1;
	VoaCntrler model;
	
	int compteur;
	int compteur2;
	int distance;
	int compte;
	private ArrayList<Integer> TabStdin; 
	
	public CntrlerListeDistances(ListeDistances vue,VoaInterface vue_1,VoaCntrler model) {
		
		this.vue = vue;
		this.vue_1 = vue_1;
		
		compteur = 0;
		compteur2=1;
		compte=0;
		distance=0;
		TabStdin = new ArrayList<Integer>();
		
		
		
		if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnSymetrie().isSelected())
		{
		vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
		vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compteur2));
		}
		else
		{
			vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
			vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compte));
		}
		
		addActionListener();
		Reinitialisation();
		
	}

	


	private void Reinitialisation() {
		
		int nombreVille = Integer.parseInt(vue_1.getTextFieldNombreVilleVOA().getText());
		int nombreGeneration= Integer.parseInt(vue_1.getTextFieldNombreGenerationsVOA().getText());
		int nombrePopulation = Integer.parseInt(vue_1.getTextFieldNombrePopulationVOA().getText());
		
		VoaCntrler.tab2= new double[nombreVille];
		VoaCntrler.tab3= new int[nombreVille];
		VoaCntrler.T= new int[nombreVille];
		VoaCntrler.C0= new int[nombrePopulation];
		VoaCntrler.c= new int[nombrePopulation];
		VoaCntrler.matrix= new double[nombrePopulation][nombreVille];
		VoaCntrler.a= new int[nombreVille][nombreVille];
		VoaCntrler.matrixt= new double[nombreVille];
		VoaCntrler.matrixtt= new double[nombreVille];
		VoaCntrler.classe= new int[nombreVille];
		VoaCntrler.classe1= new int[nombreVille];
		VoaCntrler.t= new int[nombreVille];
		VoaCntrler.d= new int[nombrePopulation];
		VoaCntrler.tt=new int[nombreVille];
		VoaCntrler.tabmin=new int[nombreGeneration];	
	}


	private void addActionListener() {
		
		vue.ecouteurBtnOk(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					clickOnbtnOk();	
					
				}catch(IllegalArgumentException ex)
				{
					vue.Message(ex.getMessage());
				}	
			}

			private void clickOnbtnOk() {
				
				//manuelle symetrique
				if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnSymetrie().isSelected())
				{
					
					if(compteur < GreedySolution.tab.size()-1)
					{
						vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compteur2));
						
						distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
						TabStdin.add(distance);
						
						compteur2++;
						if(compteur2== GreedySolution.tab.size())
						{
							compteur++;
							compteur2=compteur+1;
						}
						
						
					if(compteur==GreedySolution.tab.size()-1 )
						{
							compteur2=compteur;
							vue.fermerFenetre();
							TransferDistanceMatrice();
							RemplissageTableau();
							
							AfficheDistanceVoa vue= new AfficheDistanceVoa();
							VOA model= new VOA(vue_1);
							ContrlerAfficheDistanceVOA control = new ContrlerAfficheDistanceVOA(vue,vue_1,model);
							control.run();
						}
						
						vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compteur2));
						
						vue.getTextFieldDistanceVilles().setText("");	
					}
					
					
				}
				
				
				//manuelle asymetrique
				if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnAsymetrie().isSelected())
				{
					if(compteur < GreedySolution.tab.size())
					{	
						vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compte));
						
						if(GreedySolution.tab.get(compte).equalsIgnoreCase(GreedySolution.tab.get(compteur)))
						{
							VoaCntrler.a[compteur][compte]=0;
							compte++;
							
							if(compte == GreedySolution.tab.size())
							{
								compteur++;
								compte=0;
							}
							
							if(compteur==GreedySolution.tab.size())
							{
									vue.fermerFenetre();
									RemplissageTableau();
						
									AfficheDistanceVoa vue= new AfficheDistanceVoa();
									VOA model= new VOA(vue_1);
									ContrlerAfficheDistanceVOA control = new ContrlerAfficheDistanceVOA(vue,vue_1,model);
									control.run();
							}
							
							vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compte));
							vue.getTextFieldDistanceVilles().setText("");		
						}
						else
						{
							if(vue.getTextFieldDistanceVilles().getText().isEmpty())
							{
								throw new IllegalArgumentException("Entrez une valeur svp!!!");
							}
							else
							{
								distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
								VoaCntrler.a[compteur][compte]=distance;
								compte++;
								
								if(compte == GreedySolution.tab.size())
								{
									compteur++;
									compte=0;
								}
								vue.getLblAfficheVille_1().setText(GreedySolution.tab.get(compteur));
								vue.getLblAfficheVille_2().setText(GreedySolution.tab.get(compte));
								vue.getTextFieldDistanceVilles().setText("");
							}
							
						}
							
					}
						
				}
				
					
			}

			private void TransferDistanceMatrice() {
				
				int taille = GreedySolution.tab.size();
				int index=0;
				for(int i=0; i<taille;i++)
				{
					for(int j=0; j<taille;j++)
					{
						if(i==j)
						{
							VoaCntrler.a[i][j]=0;
						}
						if(j<=i)
						{
							VoaCntrler.a[i][j]=VoaCntrler.a[j][i];
						}
						else
						{
							VoaCntrler.a[i][j]=TabStdin.get(index);
							index++;
						}
					}
				}
				
			}

			private void RemplissageTableau() {

				// Affichage de mon tableau
				DefaultTableModel model = (DefaultTableModel)vue_1.getMytable().getModel();
				model.setRowCount(0);
				int taille = GreedySolution.tab.size();
				taille = taille * taille;
				Object [] row =new Object [taille];
				
				for(int i=0; i<GreedySolution.tab.size();i++)
				{
					
					for(int j=0; j<GreedySolution.tab.size();j++)
					{
						row[0] = GreedySolution.tab.get(i);
						row[1] = GreedySolution.tab.get(j);
						row[2] =VoaCntrler.a[i][j];
						
						model.addRow(row);
					}		
				}	
			}
		});
		
	}
	
	
	public void run()
	{
		vue.run();
	}

}
