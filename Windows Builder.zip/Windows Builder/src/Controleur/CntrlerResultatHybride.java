package Controleur;

import java.util.Random;


import javax.swing.table.DefaultTableModel;

import Modele_tsp.GreedySolution;
import Modele_tsp.Hybride;
import Modele_tsp.population;
import vue.HybridationInterface;
import vue.ResultatHybrid;

public class CntrlerResultatHybride {

	
	ResultatHybrid vue;
	HybridationInterface vue_1;

	int NbreVille;
	int TaillePopulation;
	int Rayon;
	int NbreSolGreedy;
	int NbreVirus;
	int NbreGneration;
	
	
	public CntrlerResultatHybride(ResultatHybrid vue,HybridationInterface vue_1) {
		
		this.vue = vue;
		this.vue_1 = vue_1;
		
		CntrlerHybridation.yy=Math.random();
		CntrlerHybridation.val=(double) Math.round((CntrlerHybridation.yy * 100)/100);
		RecuperationDonnee();
		Resolution();
		
	}
	



	private void RecuperationDonnee() {
		
		NbreVille = Integer.parseInt(vue_1.getTextFieldVille().getText());
		TaillePopulation = Integer.parseInt(vue_1.getTextFieldNbrePopulation().getText());
		Rayon = Integer.parseInt(vue_1.getTextFieldRayon().getText());
		NbreSolGreedy = Integer.parseInt(vue_1.getTextFieldNbreSolutionGreedy().getText());
		NbreVirus = Integer.parseInt(vue_1.getTextFieldNbreVirus().getText());
		NbreGneration = Integer.parseInt(vue_1.getTextFieldGeneration().getText());	
	}
	
	

	private void Resolution() {
		
		if(vue_1.getRdbtnHbrydSimple().isSelected())
		{
			ResolutionHybrideSimple();
			afficheDistanceMin();
			afficheChemeinMin();
		}
		
		if(vue_1.getRdbtnHbrydMultiple().isSelected())
		{
			ResolutionHybrideMultiple();
			afficheDistanceMin();
			afficheChemeinMin();
		}
			
	}
	
	
	

	private void afficheChemeinMin() {

		DefaultTableModel model = (DefaultTableModel)vue.getTableChemin().getModel();
		model.setRowCount(0);
		int taille = GreedySolution.tabHybridation.size();
		Object [] row =new Object [taille];
		
		for(int i=0; i<taille;i++)
		{		
			row[0] =GreedySolution.tabHybridation.get(CntrlerHybridation.tabSol[CntrlerHybridation.ind][i]);
			model.addRow(row);		
		}
		row[0] =GreedySolution.tabHybridation.get(CntrlerHybridation.tabSol[CntrlerHybridation.ind][0]);
		model.addRow(row);	
		
	}


	private void afficheDistanceMin() {
		
		vue.getTextFieldDistanceMin().setText(String.valueOf(CntrlerHybridation.min));	
	}

	
	
	private void ResolutionHybrideMultiple() {
	
		
		CntrlerHybridation.tabSol=new int[NbreGneration][NbreVille];
		CntrlerHybridation.tabmin=new int[NbreGneration];	
		CntrlerHybridation.best1=new int[NbreVille];
		
			
			for(int ge=0;ge<NbreGneration;ge++) {
				
				
				CntrlerHybridation.best=Integer.MAX_VALUE;
				CntrlerHybridation.C0= new double[TaillePopulation];
				CntrlerHybridation.c= new double[TaillePopulation];
				CntrlerHybridation.d= new double[TaillePopulation];
				CntrlerHybridation.matrix= new double[TaillePopulation][NbreVille];
				CntrlerHybridation.matrixV= new int[TaillePopulation][NbreVille];
				CntrlerHybridation.matrixVV= new int[TaillePopulation][NbreVille];
				
	 
				   for( CntrlerHybridation.f=0;CntrlerHybridation.f<TaillePopulation;CntrlerHybridation.f++) {
					   
					   Hybride.remplir(CntrlerHybridation.matrix[CntrlerHybridation.f], CntrlerHybridation.tab2,NbreVille);
					   CntrlerHybridation.tab2 =population. triDouble(CntrlerHybridation.tab2,NbreVille);
					   Hybride.classementDouble(CntrlerHybridation.matrix[CntrlerHybridation.f],CntrlerHybridation.tab2,CntrlerHybridation.tab3,NbreVille);
					   Hybride.remplirV(CntrlerHybridation.matrixV, CntrlerHybridation.tab3,CntrlerHybridation.f,NbreVille);
					  Hybride.r�cupmat(CntrlerHybridation.tab3,CntrlerHybridation.T,NbreVille);
					   
					  CntrlerHybridation.c[CntrlerHybridation.f] = Hybride.somd1tab(CntrlerHybridation.T,NbreVille);
					  CntrlerHybridation.C0[CntrlerHybridation.f] = Hybride.somd1tab(CntrlerHybridation.T,NbreVille);
					   	  
			   }	
				  
				   Hybride.ajoutGreedyMultiple(CntrlerHybridation.C0, CntrlerHybridation.c, CntrlerHybridation.matrixV,CntrlerHybridation.matrix,NbreVille,TaillePopulation); 						  					   
					
				   Hybride.BestMin(CntrlerHybridation.c, CntrlerHybridation.matrixV,NbreVille,TaillePopulation);
				   
					  CntrlerHybridation.c=population.tri(CntrlerHybridation.c,NbreVille); 
					   
					   int [] index= new int[TaillePopulation];
					   Hybride.classement(CntrlerHybridation.c,CntrlerHybridation.C0,index,TaillePopulation);
					   
					   
						for (int i = 0; i < NbreVirus; ++i) {
							
							CntrlerHybridation.x=new Random().nextInt(NbreVille);
							  Hybride. exploitation(CntrlerHybridation.matrix[index[i]],Rayon,CntrlerHybridation.x);
							  								 
							  Hybride.copitab(CntrlerHybridation.matrixt,CntrlerHybridation.matrix,index,i,NbreVille);
							  CntrlerHybridation.matrixt= population.triDouble(CntrlerHybridation.matrixt,NbreVille);
							  Hybride.classementDouble(CntrlerHybridation.matrix[index[i]],CntrlerHybridation.matrixt,CntrlerHybridation.classe,NbreVille);
							  
							   Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe,i,NbreVille);
							   Hybride.r�cupmat(CntrlerHybridation.classe,CntrlerHybridation.t,NbreVille);
							   CntrlerHybridation.d[i]=	Hybride.somd1tab(CntrlerHybridation.t,NbreVille);
							 
					  
						}	  
						
						
								for (int i = NbreVirus; i < TaillePopulation; ++i) {
							
							  Hybride. inverse(CntrlerHybridation.matrix[index[i]]);
							  Hybride.copitab(CntrlerHybridation.matrixtt, CntrlerHybridation.matrix, index, i,NbreVille);

							  CntrlerHybridation.matrixtt=population.triDouble(CntrlerHybridation.matrixtt,NbreVille);								 
							 Hybride.classementDouble(CntrlerHybridation.matrix[index[i]],CntrlerHybridation.matrixtt,CntrlerHybridation.classe1,NbreVille);
							 Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe1,i,NbreVille);

							   Hybride.r�cupmat(CntrlerHybridation.classe1,CntrlerHybridation.tt,NbreVille);
							   CntrlerHybridation.d[i]=	Hybride.somd1tab(CntrlerHybridation.tt,NbreVille);
							 
						}
						Hybride.BestMin(CntrlerHybridation.d, CntrlerHybridation.matrixVV,NbreVille,TaillePopulation);

						
				for(int vi=0;vi<NbreGneration;vi++) {
					for (int i1 = 0; i1 < TaillePopulation; ++i1)
					{
						   Hybride.antivirus(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.val,NbreVille);
					}
			   if(CntrlerHybridation.v==1 && NbreVirus>1) {

				   NbreVirus--;

				for (int i1 = 0; i1 < NbreVirus; ++i1) {

					CntrlerHybridation.x=new Random().nextInt(NbreVille);
					  Hybride.exploitation(CntrlerHybridation.matrix[index[i1]],Rayon,CntrlerHybridation.x);
						 Hybride.copitab(CntrlerHybridation.matrixt,CntrlerHybridation.matrix,index,i1,NbreVille);
						 CntrlerHybridation.matrixt= population.triDouble(CntrlerHybridation.matrixt,NbreVille);						  
					   Hybride.classementDouble(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.matrixt,CntrlerHybridation.classe,NbreVille);
					   Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe,i1,NbreVille);
					   Hybride.r�cupmat(CntrlerHybridation.classe,CntrlerHybridation.t,NbreVille);
					   CntrlerHybridation.d[i1]=Hybride.somd1tab(CntrlerHybridation.t,NbreVille);
			  
				}	  
					  

				
				for (int i1 = NbreVirus; i1 < TaillePopulation; ++i1) {

					  Hybride. inverse(CntrlerHybridation.matrix[index[i1]]);
					  Hybride.copitab(CntrlerHybridation.matrixtt, CntrlerHybridation.matrix, index, i1,NbreVille);
					  CntrlerHybridation.matrixtt=population.triDouble(CntrlerHybridation.matrixtt,NbreVille);			 
					 Hybride.classementDouble(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.matrixtt,CntrlerHybridation.classe1,NbreVille);
					 Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe1,i1,NbreVille);
					   Hybride.r�cupmat(CntrlerHybridation.classe1,CntrlerHybridation.tt,NbreVille);
					   CntrlerHybridation.d[i1]=Hybride.somd1tab(CntrlerHybridation.tt,NbreVille);
					   
				}
				
				Hybride.BestMin(CntrlerHybridation.d, CntrlerHybridation.matrixVV,NbreVille,TaillePopulation);						 
			}
			   
		}
				Hybride.stockSol(CntrlerHybridation.tabSol, CntrlerHybridation.best1, ge,NbreVille);
				CntrlerHybridation.tabmin[ge]=CntrlerHybridation.best;
				
				
			}
			Hybride.TotalMin(CntrlerHybridation.tabmin,NbreGneration); 
		
}
	
	
	
	
	
	
	

	private void ResolutionHybrideSimple() {
		
		CntrlerHybridation.tabSol=new int[NbreGneration][NbreVille];
		CntrlerHybridation.tabmin=new int[NbreGneration];
		CntrlerHybridation.best1=new int[NbreVille];
		CntrlerHybridation.tabdis=new int[NbreGneration];
		
		for(int ge=0;ge<NbreGneration;ge++) {
			
			CntrlerHybridation.best=Integer.MAX_VALUE;
			
			CntrlerHybridation.C0= new double[TaillePopulation];
			CntrlerHybridation.c= new double[TaillePopulation];
			CntrlerHybridation.d= new double[TaillePopulation];
			CntrlerHybridation.matrix= new double[TaillePopulation][NbreVille];
			CntrlerHybridation.matrixV= new int[TaillePopulation][NbreVille];
			CntrlerHybridation.matrixVV= new int[TaillePopulation][NbreVille];
			
			
			 for(CntrlerHybridation.f=0; CntrlerHybridation.f < TaillePopulation; CntrlerHybridation.f++)
			 {
				 
			 Hybride.remplir(CntrlerHybridation.matrix[CntrlerHybridation.f],CntrlerHybridation.tab2,NbreVille);
			 CntrlerHybridation.tab2 =population.triDouble(CntrlerHybridation.tab2, NbreVille);
			 Hybride.classementDouble(CntrlerHybridation.matrix[CntrlerHybridation.f],CntrlerHybridation.tab2,CntrlerHybridation.tab3,NbreVille);
			 Hybride.remplirV(CntrlerHybridation.matrixV, CntrlerHybridation.tab3,CntrlerHybridation.f,NbreVille);
			 Hybride.r�cupmat(CntrlerHybridation.tab3,CntrlerHybridation.T,NbreVille);
			 
			 CntrlerHybridation.c[CntrlerHybridation.f] = Hybride.somd1tab(CntrlerHybridation.T,NbreVille);
			 CntrlerHybridation.C0[CntrlerHybridation.f] = Hybride.somd1tab(CntrlerHybridation.T,NbreVille);
			 
			 }
			 
			 	Hybride.ajoutGreedyS(CntrlerHybridation.C0, CntrlerHybridation.c, CntrlerHybridation.matrixV, CntrlerHybridation.matrix,NbreVille,TaillePopulation);
			 	
			 	 Hybride.BestMin(CntrlerHybridation.c, CntrlerHybridation.matrixV,NbreVille,TaillePopulation);
			 	 
			 	CntrlerHybridation.c=population.tri(CntrlerHybridation.c,NbreVille); 
			 	
			 	 int [] index= new int[TaillePopulation];
			 	 
			 	 Hybride.classement(CntrlerHybridation.c,CntrlerHybridation.C0,index,TaillePopulation);
			 	 
			 	 
			 	for (int i = 0; i < NbreVirus; ++i) {
			 		
			CntrlerHybridation.x=new Random().nextInt(NbreVille);	
			Hybride. inverse(CntrlerHybridation.matrix[index[i]]);
			Hybride.copitab(CntrlerHybridation.matrixtt, CntrlerHybridation.matrix, index, i,NbreVille);
			CntrlerHybridation.matrixtt=population.triDouble(CntrlerHybridation.matrixtt,NbreVille);
			
			Hybride.classementDouble(CntrlerHybridation.matrix[index[i]],CntrlerHybridation.matrixtt,CntrlerHybridation.classe1,NbreVille);
			Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe1,i,NbreVille);
			Hybride.r�cupmat(CntrlerHybridation.classe1,CntrlerHybridation.tt,NbreVille);
			CntrlerHybridation.d[i]=Hybride.somd1tab(CntrlerHybridation.tt,NbreVille); 
			  
				}
			 	
			 	for (int i = NbreVirus; i < TaillePopulation; ++i) {
					
					  Hybride. inverse(CntrlerHybridation.matrix[index[i]]);
					  Hybride.copitab(CntrlerHybridation.matrixtt, CntrlerHybridation.matrix, index, i,NbreVille);
					  CntrlerHybridation.matrixtt=population.triDouble(CntrlerHybridation.matrixtt,NbreVille);
					  Hybride.classementDouble(CntrlerHybridation.matrix[index[i]],CntrlerHybridation.matrixtt,CntrlerHybridation.classe1,NbreVille);
					  Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe1,i,NbreVille);
					  Hybride.r�cupmat(CntrlerHybridation.classe1,CntrlerHybridation.tt,NbreVille);
					  CntrlerHybridation.d[i]=	Hybride.somd1tab(CntrlerHybridation.tt,NbreVille);
					 
				}
			 	
			 	Hybride.BestMin(CntrlerHybridation.d, CntrlerHybridation.matrixVV,NbreVille,TaillePopulation);
			 	
			 	for(int vi=0;vi<NbreGneration;vi++) {
					
			 		for (int i1 = 0; i1 < TaillePopulation; ++i1)
					{
						Hybride.antivirus(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.val,NbreVille);
					}
					
					if(CntrlerHybridation.v==1 && NbreVirus>1) {
				   
						NbreVirus--;
				   
				for (int i1 = 0; i1 < NbreVirus; ++i1) {
					 
					CntrlerHybridation.x=new Random().nextInt(NbreVille);
					Hybride.exploitation(CntrlerHybridation.matrix[index[i1]],Rayon,CntrlerHybridation.x);		 	 
					Hybride.copitab(CntrlerHybridation.matrixt,CntrlerHybridation.matrix,index,i1,NbreVille); 
					CntrlerHybridation.matrixt= population.triDouble(CntrlerHybridation.matrixt,NbreVille);
				 	Hybride.classementDouble(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.matrixt,CntrlerHybridation.classe,NbreVille);
					
					   
					   Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe,i1,NbreVille);
					   Hybride.r�cupmat(CntrlerHybridation.classe,CntrlerHybridation.t,NbreVille);
					   CntrlerHybridation.d[i1]=Hybride.somd1tab(CntrlerHybridation.t,NbreVille); 
			  
				}	  
					  
				for (int i1 = NbreVirus; i1 < TaillePopulation; ++i1) {
					
					Hybride.inverse(CntrlerHybridation.matrix[index[i1]]);
			 		Hybride.copitab(CntrlerHybridation.matrixtt, CntrlerHybridation.matrix, index, i1,NbreVille);
					  
			 		CntrlerHybridation.matrixtt=population.triDouble(CntrlerHybridation.matrixtt,NbreVille);
			 		Hybride.classementDouble(CntrlerHybridation.matrix[index[i1]],CntrlerHybridation.matrixtt,CntrlerHybridation.classe1,NbreVille);
			 		
			 		Hybride.remplirV(CntrlerHybridation.matrixVV, CntrlerHybridation.classe1,i1,NbreVille);
					Hybride.r�cupmat(CntrlerHybridation.classe1,CntrlerHybridation.tt,NbreVille);
					CntrlerHybridation.d[i1]=Hybride.somd1tab(CntrlerHybridation.tt,NbreVille);
			 		
				}
				Hybride.BestMin(CntrlerHybridation.d, CntrlerHybridation.matrixVV,NbreVille,TaillePopulation);   
				} 
			}
			 	
			Hybride.stockSol(CntrlerHybridation.tabSol, CntrlerHybridation.best1, ge,NbreVille);
			CntrlerHybridation.tabmin[ge]=CntrlerHybridation.best;	
		}
		
		Hybride.TotalMin(CntrlerHybridation.tabmin,NbreGneration); 
		
	}
	
	
	
	public void run()
	{
		vue.run();
	}
}
