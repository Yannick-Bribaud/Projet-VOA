package Controleur;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import Modele_tsp.GreedySolution;
import vue.HybridationInterface;
import vue.ListeDistances;
import vue.ResultatHybrid;




public class CntrolrDistanceHybride {
	
		ListeDistances vue;
		HybridationInterface vue_1;
	
		int compteur;
		int compteur2;
		int compte;
		int distance;
		private ArrayList<Integer> TabStdin; 
	
	public CntrolrDistanceHybride(ListeDistances vue,HybridationInterface vue_1) {
		
		this.vue = vue;
		this.vue_1 = vue_1;
		
		 compteur = 0;
		 compteur2= 1;
		 compte	  = 0;
		 distance = 0;
		 
		 TabStdin= new ArrayList<Integer>();
		 
		 
		 if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnSymetrique().isSelected())
			{
			 
				vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
				vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compteur2));
			}
			else
			{
				vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
				vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compte));
			}
		
		
		AddEcouteurBtnAddDistance();
	}
	
	
	
	private void AddEcouteurBtnAddDistance() {
		
		vue.EcouteurBtnAdd(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					ClickOnAdd();
				}catch(IllegalArgumentException ex) {
					
					vue.Messages(ex.getMessage());
					
				}
				
				
			}

				
			
			private void ClickOnAdd() {
				
				
				if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnSymetrique().isSelected() && vue_1.getRdbtnHbrydSimple().isSelected())
				{
					
					if(compteur < GreedySolution.tabHybridation.size()-1)
					{
						vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compteur2));
						
						distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
						TabStdin.add(distance);
						
						compteur2++;
						
						if(compteur2== GreedySolution.tabHybridation.size())
						{
							compteur++;
							compteur2=compteur+1;
						}
						
						
					if(compteur==GreedySolution.tabHybridation.size()-1 )
						{
							compteur2=compteur;
							vue.fermerFenetre();
							TransferDistanceMatrice();
							AfficherDistanceVilles();
							
							ResultatHybrid vues = new ResultatHybrid();
							CntrlerResultatHybride control = new CntrlerResultatHybride(vues,vue_1);
							control.run();		
						}
						
						vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compteur2));
						
						vue.getTextFieldDistanceVilles().setText("");	
					}
					
					
				}
				
				
				// Manuelle Asymetrique
				if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnAsymetrique().isSelected())
				{
					if(compteur < GreedySolution.tabHybridation.size())
					{	
						vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compte));
						
						
						if(GreedySolution.tabHybridation.get(compte).equalsIgnoreCase(GreedySolution.tabHybridation.get(compteur)))
						{
							CntrlerHybridation.TableauDistanceHybrid[compteur][compte]=0;
							
							compte++;
							if(compte == GreedySolution.tabHybridation.size())
							{
								compteur++;
								compte=0;
							}
							
							if(compteur==GreedySolution.tabHybridation.size())
							{
								vue.fermerFenetre();
								AfficherDistanceVilles();
								
								ResultatHybrid vue = new ResultatHybrid();
								CntrlerResultatHybride control = new CntrlerResultatHybride(vue,vue_1);
								control.run();
							}
							
							vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compte));
							vue.getTextFieldDistanceVilles().setText("");
							
						}
						else
						{
							if(vue.getTextFieldDistanceVilles().getText().isEmpty())
							{
								throw new IllegalArgumentException("Entrez une valeur svp!!!");
							}
							else
							{
								distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
								CntrlerHybridation.TableauDistanceHybrid[compteur][compte]=distance;
								
								compte++;
								
								if(compte == GreedySolution.tabHybridation.size())
								{
									compteur++;
									compte=0;
								}
								
								vue.getLblAfficheVille_1().setText(GreedySolution.tabHybridation.get(compteur));
								vue.getLblAfficheVille_2().setText(GreedySolution.tabHybridation.get(compte));
								vue.getTextFieldDistanceVilles().setText("");	
								
							}
						}
					}
				}
			}



			private void TransferDistanceMatrice() {
				
				int taille = GreedySolution.tabHybridation.size();
				int index=0;
				for(int i=0; i<taille;i++)
				{
					for(int j=0; j<taille;j++)
					{
						if(i==j)
						{	CntrlerHybridation.TableauDistanceHybrid[i][j]=0; }
						if(j<=i)
						{  CntrlerHybridation.TableauDistanceHybrid[i][j]=CntrlerHybridation.TableauDistanceHybrid[j][i]; }
						else
						{	CntrlerHybridation.TableauDistanceHybrid[i][j]=TabStdin.get(index);
							index++; }
					}
				}	
			}


			private void AfficherDistanceVilles() {
				
				// Affichage de mon tableau
				DefaultTableModel model = (DefaultTableModel)vue_1.getTableVilleDistance().getModel();
				model.setRowCount(0);
				int taille = GreedySolution.tabHybridation.size();
				taille = taille * taille;
				
				Object [] row =new Object [taille];
				
				for(int i=0; i<GreedySolution.tabHybridation.size();i++)
				{
					for(int j=0; j<GreedySolution.tabHybridation.size();j++)
					{
						
						row[0] = GreedySolution.tabHybridation.get(i);
						row[1] = GreedySolution.tabHybridation.get(j);
						row[2] = CntrlerHybridation.TableauDistanceHybrid[i][j];
						
					   model.addRow(row);
					}		
				}	
				
			}
		});
		
	}



	public void run()
	{
		vue.run();
	}

}
