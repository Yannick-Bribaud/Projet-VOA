package Controleur;

import java.util.Random;

import javax.swing.table.DefaultTableModel;

import Modele_tsp.GreedySolution;
import Modele_tsp.VOA;
import Modele_tsp.population;
import vue.AfficheDistanceVoa;
import vue.VoaInterface;

public class ContrlerAfficheDistanceVOA {
	
	AfficheDistanceVoa vue;
	VoaInterface Interface;
	VOA models;
	
	int nombreGeneration;
	int nombrePopulation;
	int nombreVille;
	int nombreR;
	int nombreVirus;
	
	
	public ContrlerAfficheDistanceVOA(AfficheDistanceVoa vue,VoaInterface Interface,VOA models) {
		
		this.vue = vue;
		this.Interface = Interface;
		this.models = models;
		
		VoaCntrler.yy = Math.random();
		VoaCntrler.val= Math.round(VoaCntrler.yy * 100)/100;
		
		nombreGeneration = Integer.parseInt(Interface.getTextFieldNombreGenerationsVOA().getText());
		nombrePopulation = Integer.parseInt(Interface.getTextFieldNombrePopulationVOA().getText());
		nombreVille = Integer.parseInt(Interface.getTextFieldNombreVilleVOA().getText());
		nombreR = Integer.parseInt(Interface.getTextFieldNbreRVOA().getText());
		nombreVirus = Integer.parseInt(Interface.getTextFieldNbreVirus().getText());
		
		methodeVOA();
	}

	private void methodeVOA() {
		
		VoaCntrler.tabSol=new int[nombreGeneration][nombreVille];
		VoaCntrler.tabmin=new int[nombreGeneration];
		VoaCntrler.best1=new int[nombreVille];
		
		for(int ge=0; ge<nombreGeneration;ge++)
		{
			VoaCntrler.best=Integer.MAX_VALUE;
			VoaCntrler.C0= new int [nombrePopulation];
			VoaCntrler.c= new int[nombrePopulation];
			VoaCntrler.d= new int[nombrePopulation];
			VoaCntrler.matrix= new double[nombrePopulation][nombreVille];
			VoaCntrler.matrixV= new int[nombrePopulation][nombreVille];
			VoaCntrler.matrixVV= new int[nombrePopulation][nombreVille];
			
			for(VoaCntrler.f=0; VoaCntrler.f< nombrePopulation; VoaCntrler.f++)
			{
				   VOA.remplir(VoaCntrler.matrix[VoaCntrler.f], VoaCntrler.tab2,nombreVille);
				   VoaCntrler.tab2 =population. triDouble(VoaCntrler.tab2,nombreVille); 
				   VOA.classementDouble(VoaCntrler.matrix[VoaCntrler.f],VoaCntrler.tab2,VoaCntrler.tab3,nombreVille);
				   VOA.remplirV(VoaCntrler.matrixV, VoaCntrler.tab3,VoaCntrler.f,nombreVille);
				  VOA.r�cupmat(VoaCntrler.tab3,VoaCntrler.T,nombreVille);
				  VoaCntrler.c[VoaCntrler.f] =  VOA.somd1tabInt(VoaCntrler.T,nombreVille);
				  VoaCntrler.C0[VoaCntrler.f] = VOA.somd1tabInt(VoaCntrler.T,nombreVille);
			}
			
			VOA.BestMin(VoaCntrler.c, VoaCntrler.matrixV,nombrePopulation);
			
			VoaCntrler.c=population.triVoa(VoaCntrler.c,nombreVille); 
			
			 int [] index= new int[nombrePopulation];
			 VOA.classement(VoaCntrler.c,VoaCntrler.C0,index,nombrePopulation);
			 
			 
			 for (int i = 0; i < nombreVirus; ++i) {

				 	VoaCntrler.x=new Random().nextInt(nombreVille);
					VOA. exploitation(VoaCntrler.matrix[index[i]],nombreR,VoaCntrler.x); 
					VOA.copitab(VoaCntrler.matrixt,VoaCntrler.matrix,index,i,nombreVille);
					VoaCntrler.matrixt= population.triDouble(VoaCntrler.matrixt,nombreVille);
					VOA.classementDouble(VoaCntrler.matrix[index[i]],VoaCntrler.matrixt,VoaCntrler.classe,nombreVille); 
					VOA.remplirV(VoaCntrler.matrixVV, VoaCntrler.classe,i,nombreVille);
					VOA.r�cupmat(VoaCntrler.classe,VoaCntrler.t,nombreVille);
					VoaCntrler.d[i]=VOA.somd1tabInt(VoaCntrler.t,nombreVille);	 
				}
			 
			 for (int i = nombreVirus; i < nombrePopulation; ++i) {
				
				 VOA. inverse(VoaCntrler.matrix[index[i]]);
				 VOA.copitab(VoaCntrler.matrixtt, VoaCntrler.matrix, index, i,nombreVille);
				 VoaCntrler.matrixtt=population.triDouble(VoaCntrler.matrixtt,nombreVille);
				 VOA.classementDouble(VoaCntrler.matrix[index[i]],VoaCntrler.matrixtt,VoaCntrler.classe1,nombreVille);
				 VOA.remplirV(VoaCntrler.matrixVV, VoaCntrler.classe1,i,nombreVille);
				 VOA.r�cupmat(VoaCntrler.classe1,VoaCntrler.tt,nombreVille);
				 VoaCntrler.d[i]=VOA.somd1tabInt(VoaCntrler.tt,nombreVille);
				 
			}
			 
			 VOA.BestMin(VoaCntrler.d,  VoaCntrler.matrixVV,nombrePopulation);
			 
			 for(int vi=0; vi < nombreGeneration; vi++) {
				 
		
					for (int i1 = 0; i1 < nombrePopulation; ++i1)
					{
						   VOA.antivirus(VoaCntrler.matrix[index[i1]], VoaCntrler.val,nombreVille);
					}
			   if(VoaCntrler.v==1 && nombreVirus>1) {
				  
				   nombreVirus--;

				for (int i1 = 0; i1 < nombreVirus; ++i1) {

					VoaCntrler.x=new Random().nextInt(nombreVille);
					VOA.exploitation(VoaCntrler.matrix[index[i1]],nombreR,VoaCntrler.x);
					VOA.copitab(VoaCntrler.matrixt,VoaCntrler.matrix,index,i1,nombreVille); 
				    VoaCntrler.matrixt= population.triDouble(VoaCntrler.matrixt,nombreVille);
					VOA.classementDouble(VoaCntrler.matrix[index[i1]],VoaCntrler.matrixt,VoaCntrler.classe,nombreVille);
					VOA.remplirV(VoaCntrler.matrixVV, VoaCntrler.classe,i1,nombreVille);
					VOA.r�cupmat(VoaCntrler.classe,VoaCntrler.t,nombreVille);
					VoaCntrler.d[i1]=VOA.somd1tabInt(VoaCntrler.t,nombreVille);

				 
				}	
				
				
				for (int i1 = nombreVirus; i1 < nombrePopulation; ++i1) {
					
					  VOA. inverse(VoaCntrler.matrix[index[i1]]);				  
					  VOA.copitab(VoaCntrler.matrixtt, VoaCntrler.matrix, index, i1,nombreVille);
					  VoaCntrler.matrixtt=population.triDouble(VoaCntrler.matrixtt,nombreVille);
					  VOA.classementDouble(VoaCntrler.matrix[index[i1]],VoaCntrler.matrixtt,VoaCntrler.classe1,nombreVille);
					  VOA.remplirV(VoaCntrler.matrixVV, VoaCntrler.classe1,i1,nombreVille);
					  VOA.r�cupmat(VoaCntrler.classe1,VoaCntrler.tt,nombreVille);
					  VoaCntrler.d[i1]=VOA.somd1tabInt(VoaCntrler.tt,nombreVille);
					     
				}
				
				 VOA.BestMin(VoaCntrler.d, VoaCntrler.matrixVV,nombrePopulation);
				 
			   }
			   
			 }
			 
			 VOA.stockSol(VoaCntrler.tabSol, VoaCntrler.best1, ge,nombreVille);
			 VoaCntrler.tabmin[ge]=VoaCntrler.best;
			 
		}
		
		VOA.TotalMin(VoaCntrler.tabmin,nombreGeneration); 
		
		affichageDesDistancesMinimales();
		afficheDistance();
	}
			 
			 
			
	
	private void afficheDistance() {
		double resultat = VoaCntrler.min;
	vue.getTextFieldDistanceAffiche().setText(String.valueOf(resultat));	
	}

	private void affichageDesDistancesMinimales() {
		
		//AFFICHAGE DU TABLEAU
		DefaultTableModel model = (DefaultTableModel)vue.getTableListeDistanceMinimale().getModel();
		int taille = GreedySolution.tab.size();
		Object [] row =new Object [taille];
		
		for(int i=0; i<taille;i++)
		{
			row[0] = GreedySolution.tab.get(VoaCntrler.tabSol[VoaCntrler.ind][i]);
				model.addRow(row);				
		}
		
		row[0] = GreedySolution.tab.get(VoaCntrler.tabSol[VoaCntrler.ind][0]);
		model.addRow(row);
			
	}	


	public void run()
	{
		vue.run();
	}
	
	

}
