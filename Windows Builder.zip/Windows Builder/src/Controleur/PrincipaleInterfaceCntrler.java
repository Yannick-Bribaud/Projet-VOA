package Controleur;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;

import Modele_tsp.GreedySolution;
import vue.GreedySolutionInterface;
import vue.HybridationInterface;
import vue.PrincipaleInterface;
import vue.VoaInterface;


public class PrincipaleInterfaceCntrler {
	
	PrincipaleInterface vue_1 ;
	
	public PrincipaleInterfaceCntrler(PrincipaleInterface vue_1 ) {
		this.vue_1 = vue_1;
		addActionlisterGreedySolution();
		addActionListenerVOA();
		addActionListenerHybridation();
		
	}
	
	
	
	
	private void addActionListenerHybridation() {
		vue_1.EcouteurBtnHybride(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				HybridationInterface vue = new HybridationInterface(); 
				CntrlerHybridation control = new CntrlerHybridation(vue);
				control.run();
			}
		});
		
	}


	private void addActionListenerVOA() {
		vue_1.EcouteurBtnVoa(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ClickbtnVOA();
			}

			private void ClickbtnVOA() {
				VoaInterface vue = new VoaInterface();
				VoaCntrler controleur = new VoaCntrler(vue);
				controleur.run();	
			}
			
		});
		
	}

	private void addActionlisterGreedySolution() {
		vue_1.EcouteurBtnGreedySolution(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ClickOnbuttonGreedy();	
			}

			private void ClickOnbuttonGreedy() {
				
				GreedySolutionInterface vue = new GreedySolutionInterface();
				GreedySolution model = new GreedySolution();
				greedySolutionCntrler controleur =new greedySolutionCntrler(vue,model);
				controleur.run();
			}
			
		});
		
	}
	
	public void run()
	{
		vue_1.run();
	}

	

}
