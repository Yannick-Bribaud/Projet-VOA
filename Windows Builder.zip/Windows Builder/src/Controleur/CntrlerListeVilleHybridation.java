package Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

import Modele_tsp.GreedySolution;
import Modele_tsp.Hybride;
import vue.HybridationInterface;
import vue.ListeDistances;
import vue.ListeVille;
import vue.ResultatHybrid;

public class CntrlerListeVilleHybridation {
	
	ListeVille vue;
	HybridationInterface vue_1;
	
	int nbreVille;
	String compteur;
	String nomVille;
	int compt;
	
	
	
	public CntrlerListeVilleHybridation(ListeVille vue,HybridationInterface vue_1) {
		this.vue   = vue;
		this.vue_1 = vue_1;
		
		
		nbreVille  = Integer.parseInt(vue_1.getTextFieldVille().getText());
		compt = nbreVille;
		compteur   = String.valueOf(nbreVille);
		
		vue.getLblAfficheNumVille().setText(compteur);
		
		
		GreedySolution.tabHybridation.clear();
		
		AddActionListener();
	}
	

	
	
	private void AddActionListener() {
	
		vue.EcouteurBtnValider(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					clickOnbtnValider();
				}catch(IllegalArgumentException Except)
				{
					vue.Messag(Except.getMessage());
				}
				
				
			}
			
			
			private void clickOnbtnValider() {
				
				if(vue.getTextFieldListeVille().getText().isEmpty())
				{
					throw new IllegalArgumentException("Entrez le nom d'une ville svp");
				}
				else
				{
					nomVille = vue.getTextFieldListeVille().getText();
					GreedySolution.tabHybridation.add(nomVille);
					vue.getTextFieldListeVille().setText("");
					nbreVille = nbreVille-1;
					compteur = String.valueOf(nbreVille);
					vue.getLblAfficheNumVille().setText(compteur);
					
					if(nbreVille == 0)
					{
						vue.fermer();
						AffichageListeVille();
						
						if(vue_1.getRdbtnManuelle().isSelected() && (vue_1.getRdbtnAsymetrique().isSelected()))
						{
							
							ListeDistances vue_2 = new ListeDistances();
							CntrolrDistanceHybride controleur = new  CntrolrDistanceHybride(vue_2,vue_1);
							controleur.run();
						}
						
						if(vue_1.getRdbtnManuelle().isSelected() && (vue_1.getRdbtnSymetrique().isSelected()))
						{
							
							ListeDistances vue_2 = new ListeDistances();
							CntrolrDistanceHybride controleur = new  CntrolrDistanceHybride(vue_2,vue_1);
							controleur.run();
						}
							
						if(vue_1.getRdbtnAleatoire().isSelected() && vue_1.getRdbtnAsymetrique().isSelected())
						{
							Hybride.rempliralt(CntrlerHybridation.TableauDistanceHybrid,compt);
							afficheDistanceVille();
							
							ResultatHybrid vue = new ResultatHybrid();
							CntrlerResultatHybride control = new CntrlerResultatHybride(vue,vue_1);
							control.run();
						}
						
						if(vue_1.getRdbtnAleatoire().isSelected() && vue_1.getRdbtnSymetrique().isSelected())
						{
							Hybride.RempAlea(CntrlerHybridation.TableauDistanceHybrid,compt);
							afficheDistanceVille();
							
							ResultatHybrid vue = new ResultatHybrid();
							CntrlerResultatHybride control = new CntrlerResultatHybride(vue,vue_1);
							control.run();
						}
						
						
						
					}
				}
				
			}
			

			private void afficheDistanceVille() {
				
				DefaultTableModel model = (DefaultTableModel)vue_1.getTableVilleDistance().getModel();
				model.setRowCount(0);
				int taille = GreedySolution.tabHybridation.size();
				taille = taille * taille;
				Object [] row =new Object [taille];
				
				for(int i=0; i<GreedySolution.tabHybridation.size();i++)
				{
					for(int j=0; j<GreedySolution.tabHybridation.size();j++)
					{
						row[0] = GreedySolution.tabHybridation.get(i);
						row[1] = GreedySolution.tabHybridation.get(j);
						row[2] = CntrlerHybridation.TableauDistanceHybrid[i][j];	
					    model.addRow(row);
					   
					}		
				}	
			}


			private void AffichageListeVille() {
				
				DefaultListModel<String>listeHybride = new DefaultListModel<String>();;
				listeHybride.clear();
				for(int i=0; i< GreedySolution.tabHybridation.size(); i++)
				{
					listeHybride.addElement(GreedySolution.tabHybridation.get(i));
				}
				
				vue_1.getList().setModel(listeHybride);		
			}
		});	
		
	}


	public void run()
	{
		vue.run();
	}

}
