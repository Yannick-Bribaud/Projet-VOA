package Controleur;

import java.util.ArrayList;


import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

import Modele_tsp.GreedySolution;
import vue.GreedySolutionInterface;
import vue.ResultatGreedy;


public class CntrlrResultatGreedy {
	
	ResultatGreedy vue;
	GreedySolution model;
	GreedySolutionInterface vue_1;
	
	int NbreVille;
	int SumTotal;
	static List<Integer> visitedRouteList = new ArrayList<>();
	DefaultListModel<String> List;
	
	public CntrlrResultatGreedy(ResultatGreedy vue, GreedySolutionInterface vue_1,int model) {
		
		this.vue = vue;
		this.vue_1 = vue_1;
		this.NbreVille = model;
		this.SumTotal=Integer.MAX_VALUE;
		List = new DefaultListModel<String>();
		
		afficheListeVille();
		afficheTableDistance();
		MethodeGreedy();
		
	}

	
	private void MethodeGreedy() {
		 CalculDistanceMinimale();
		 afficheDistanceMinimal();
		 AfficheListeDistanceMinimale();
	}

	
	
	private void CalculDistanceMinimale() {
		
		for(int i=0; i<NbreVille; i++)
		{
			GreedySolution.findMinRoute(greedySolutionCntrler.TableauDistance,i);
			
			if(SumTotal>GreedySolution.som)
			 {
				SumTotal=GreedySolution.som;
				visitedRouteList =GreedySolution.maliste;
			 }
		}
		
	}
	
	
private void AfficheListeDistanceMinimale() {
		
		DefaultTableModel model = (DefaultTableModel)vue.getTableDistanceMinimale().getModel();
		int taille = visitedRouteList.size();
		Object [] row =new Object [taille];
		
		for(int i=0; i<taille;i++)
		{
			int j= visitedRouteList.get(i);
			row[0] = GreedySolution.tabGreedy.get(j);
			model.addRow(row);	
			
		}	
	}


	private void afficheDistanceMinimal() {
		String distanceMinimale = String.valueOf(SumTotal);
		vue.getTextFieldAfficheDistanceMinimal().setText(distanceMinimale);	
	}


	private void afficheTableDistance() {
		
		DefaultTableModel model = (DefaultTableModel)vue.getTableDistanceVille().getModel();
		int taille = GreedySolution.tabGreedy.size();
		taille = taille * taille;
		Object [] row =new Object [taille];
		
		for(int i=0; i<GreedySolution.tabGreedy.size();i++)
		{
			for(int j=0; j<GreedySolution.tabGreedy.size();j++)
			{
				row[0] = GreedySolution.tabGreedy.get(i);
				row[1] = GreedySolution.tabGreedy.get(j);
				row[2] = greedySolutionCntrler.TableauDistance[i][j];
				
				model.addRow(row);
			}
			
				
		}
		
	}

	private void afficheListeVille() {
		
		for(int i=0; i< GreedySolution.tabGreedy.size(); i++)
		{
			List.addElement(GreedySolution.tabGreedy.get(i));
		}
		vue.getListVilles().setModel(List);
	}
	
	
	
	
	public void run()
	{
		vue.run();
	}

}
