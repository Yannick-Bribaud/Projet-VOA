package Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import Modele_tsp.GreedySolution;
import vue.HybridationInterface;
import vue.ListeVille;

public class CntrlerHybridation {

	HybridationInterface vue;
	
	int NbreVille;
	int TaillePopulation;
	int Rayon;
	int NbreSolGreedy;
	int NbreVirus;
	int NbreGneration;
	double varTestRayon;
	double varTestVirus;
	double varTestNbreGreedy;
	
	
	public static int  f;static int s;static int ii;
	public static int ind,verif,n, best;
	public static int tabdis[],min = Integer.MAX_VALUE; public static int indB;
	public static int best1[]; public static int matrixV[][]; public static int tabSol[][];
	public static int matrixVV[][]; public static int tab3 [];
	public static int classe1[]; public static int ta[];public static int classe[];
	public static int x; public static int v = 0; public static int ch;
	public static double C0[];public static double c[];public static double d[];public static int tabmin[];
	public static double[] T;
	public static double[] t;public static double tt[];
	public static double tab2[],xx,yy,val, matrix[][],  matrixt[], matrixtt[], tab[];
	public static List<Integer> TabDis = new ArrayList<>();
	
	public static int TableauDistanceHybrid[][];
	
	public CntrlerHybridation(HybridationInterface vue) {
		
		this.vue = vue;
		AddEcouteurBtnValider();
		ValeurParDefaut();
		Initialisation();
	}
	
	
	

	
	private void Initialisation() {
		TableauDistanceHybrid = null;
		GreedySolution.tabHybridation.clear();		
	}
	
	

	private void ValeurParDefaut() {
		
		vue.getTextFieldGeneration().setText(String.valueOf(60));
		vue.getTextFieldNbrePopulation().setText(String.valueOf(50));
		vue.getTextFieldNbreVirus().setText(String.valueOf(15));
		vue.getTextFieldNbreSolutionGreedy().setText(String.valueOf(5));
			
	}

	
		
	private void AddEcouteurBtnValider() {
		vue.EcouteurBtnValider(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					ClickOnbtnValider();	
				}catch(IllegalArgumentException ex) {
					
					vue.Message(ex.getMessage());
				}
					
			}
			
			
			private void ClickOnbtnValider() {
				
				if(vue.getRdbtnManuelle().isSelected() && vue.getRdbtnSymetrique().isSelected() && vue.getRdbtnHbrydMultiple().isSelected())
				{
					throw new IllegalArgumentException("Le Remplissage Manuel Sym�trique Avec l'Hybridation Multiple Risque de Planter Votre Programme.");
				}
			
				if(!(vue.getRdbtnSymetrique().isSelected() || vue.getRdbtnAsymetrique().isSelected()))
				{
					throw new IllegalArgumentException("Veuillez Selectionner le Type Remplissage Distance");
				}
				
				if(!(vue.getRdbtnAleatoire().isSelected() || vue.getRdbtnManuelle().isSelected()))
				{
					throw new IllegalArgumentException("Veuillez Selectionner le Mode Remplissage Distance");
				}
				
				if(!(vue.getRdbtnHbrydMultiple().isSelected() || vue.getRdbtnHbrydSimple().isSelected()))
				{
					throw new IllegalArgumentException("Veuillez Selectionner le Type D'Hybridation");
				}
				
				if(vue.getTextFieldVille().getText().isEmpty() || vue.getTextFieldGeneration().getText().isEmpty() ||
						vue.getTextFieldNbrePopulation().getText().isEmpty() || vue.getTextFieldNbreVirus().getText().isEmpty()
						|| vue.getTextFieldRayon().getText().isEmpty() || vue.getTextFieldNbreSolutionGreedy().getText().isEmpty())
				{
					throw new IllegalArgumentException("Veuillez Remplir tous les champs");
				}
				else
				{
					RecuperationDesDonneesDuTextField();
					
					if(NbreVille<=3 || NbreVille>1000)
					{
						throw new IllegalArgumentException("Le nombre de ville doit �tre sup�rieur � 3 et inf�rieure 1000");
					}
					
					if((NbreVille>5 && Rayon <=0) ||(NbreVille>5 && Rayon>varTestRayon))
					{
						throw new IllegalArgumentException("Le Rayon doit �tre Superieur � 0 et Inferieur � "+varTestRayon+"");
					}
					
					if((NbreVille <=5 && Rayon <=0)  || (NbreVille<=5 && Rayon >1))
					{
						throw new IllegalArgumentException("Le Rayon doit valoir strictement 1 lorsque le nombre de ville est inf�rieur ou �gal 5");
					}
					
					if(TaillePopulation <3)
					{
						throw new IllegalArgumentException("La taille de la population doit �tre strictement sup�rieure � 3");
					}
					if(TaillePopulation < NbreVirus)
					{
						throw new IllegalArgumentException("La taille de la population doit �tre sup�rieur au nombre de virus veuillez resaisir svp!");
					}
					
					if(NbreVirus<0 || NbreVirus>varTestVirus)
					{
						throw new IllegalArgumentException("Le Nombre de virus doit �tre Superieur � 0 et Inferieur ou �gal � "+varTestVirus+"");
					}
					
					if( vue.getRdbtnHbrydSimple().isSelected() && NbreSolGreedy >1)
					{
						throw new IllegalArgumentException("Le nombre de solution Greedy est strictement �gal � 1 pour une Hybridation Simple");
					}
					if((vue.getRdbtnHbrydMultiple().isSelected() && NbreSolGreedy<=2) ||(vue.getRdbtnHbrydMultiple().isSelected() && NbreSolGreedy>varTestNbreGreedy))
					{
						throw new IllegalArgumentException("Le nombre de solution Greedy est strictement sup�rieur � 2 et inf�rieur � "+varTestNbreGreedy+"");
					}
					else
					{
						TableauDistanceHybrid= new int [NbreVille][NbreVille];
							
							tab2= new double[NbreVille];
							tab3= new int[NbreVille];
							T= new double[NbreVille];
							matrixt= new double[NbreVille];
							matrixtt= new double[NbreVille];
							classe= new int[NbreVille];
							classe1= new int[NbreVille];
						    t= new double[NbreVille];
							tt=new double[NbreVille];
							
							saisieDesVilles();	
					}	
				}
				
			}


			private void saisieDesVilles() {
				
				ListeVille vue_1= new ListeVille();
				CntrlerListeVilleHybridation controleur = new CntrlerListeVilleHybridation(vue_1,vue);
				controleur.run();	
			}


			private void RecuperationDesDonneesDuTextField() {
				
				 NbreVille = Integer.parseInt(vue.getTextFieldVille().getText());
				 TaillePopulation = Integer.parseInt(vue.getTextFieldNbrePopulation().getText());
				 
				 varTestRayon = Math.round((NbreVille * 2)/10);
				 Rayon =  Integer.parseInt(vue.getTextFieldRayon().getText());
				 
				 varTestNbreGreedy = Math.round((TaillePopulation * 1)/10);
				 NbreSolGreedy = Integer.parseInt(vue.getTextFieldNbreSolutionGreedy().getText());
				 
				 varTestVirus  = Math.round((TaillePopulation * 3)/10);
				 NbreVirus = Integer.parseInt(vue.getTextFieldNbreVirus().getText());
				 NbreGneration = Integer.parseInt(vue.getTextFieldGeneration().getText());	
			}
			
		});
		
	}

	public void run()
	{
		vue.run();
	}
}
