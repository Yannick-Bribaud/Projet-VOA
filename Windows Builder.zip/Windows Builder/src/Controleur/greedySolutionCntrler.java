package Controleur;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;
import java.util.Random;

import Modele_tsp.GreedySolution;
import vue.GreedySolutionInterface;
import vue.ListeVille;




public class greedySolutionCntrler {
	
	GreedySolutionInterface vue;
	GreedySolution model;
	int nombreVille;
	public static int TableauDistance[][];
	
	public greedySolutionCntrler(GreedySolutionInterface vue, GreedySolution model) {
		
		this.vue = vue;
		this.model = model;
		AddActionListener();
		Reinitialisation();
	}
	
	
	private void Reinitialisation() {
		TableauDistance = null;
		GreedySolution.tabGreedy.clear();	
	}


	private void AddActionListener() {
		vue.EcouteurBtnOKgreedy(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ClickOnbtnOk();
					
				}catch(IllegalArgumentException exc) {
					
					vue.Message(exc.getMessage());
				}	
			}

			
			private void ClickOnbtnOk() {
				
				if( !vue.getRdbtnManuelle().isSelected() && !vue.getRdbtnAleatoire().isSelected())
				{
					throw new IllegalArgumentException(" Selectionner un mode de Remplissage des distances.");
				}
				
				if(vue.getTextFieldGreedyNombreVille().getText().isEmpty())
				{
					throw new IllegalArgumentException("Veuillez entrer le nombre de ville.");
				}
				else
				{
					nombreVille = Integer.parseInt(vue.getTextFieldGreedyNombreVille().getText());
					
					if(nombreVille>3 && nombreVille<=1000)
					{
						TableauDistance=new int [nombreVille][nombreVille];
						
						if(vue.getRdbtnManuelle().isSelected() && vue.getRdbtnAsymetrie().isSelected())
						{
							boolean choix=false;
							boolean ManuelleAsymetrique=true;
							
							ListeVille vue_1 = new ListeVille(); 
							GreedySolutionInterface vue = new GreedySolutionInterface(); 
							CntrlerListeVilleGreedy controleur = new CntrlerListeVilleGreedy(vue_1,vue,nombreVille,choix,ManuelleAsymetrique);
							controleur.run();
						}
						
						
						
						if(vue.getRdbtnManuelle().isSelected() && vue.getRdbtnSymetrie().isSelected())
						{
							boolean ManuelleSymetrique=false;
							boolean choix=false;
							ListeVille vue_1 = new ListeVille(); 
							GreedySolutionInterface vue = new GreedySolutionInterface(); 
							CntrlerListeVilleGreedy controleur = new CntrlerListeVilleGreedy(vue_1,vue,nombreVille,choix,ManuelleSymetrique);
							controleur.run();
						}
						
						
						if(vue.getRdbtnAleatoire().isSelected() && vue.getRdbtnAsymetrie().isSelected())
						{
							boolean choix=true;
							boolean ManuelleSymetrique=false;
							RemplisageAleatoireAsymetrique();
							ListeVille vue_1 = new ListeVille(); 
							GreedySolutionInterface vue = new GreedySolutionInterface(); 
							CntrlerListeVilleGreedy controleur = new CntrlerListeVilleGreedy(vue_1,vue,nombreVille,choix,ManuelleSymetrique);
							controleur.run();	
						}
						
						
						
						if(vue.getRdbtnAleatoire().isSelected() && vue.getRdbtnSymetrie().isSelected())
						{
							boolean choix=true;
							boolean ManuelleSymetrique=true;
							RemplisageAleatoireSymetrique();
							ListeVille vue_1 = new ListeVille(); 
							GreedySolutionInterface vue = new GreedySolutionInterface(); 
							CntrlerListeVilleGreedy controleur = new CntrlerListeVilleGreedy(vue_1,vue,nombreVille,choix,ManuelleSymetrique);
							controleur.run();	
						}
					}
					else
					{
						throw new IllegalArgumentException("Le nombre de ville est strictement sup�rieur � 3 et "
								+ "inf�rieur � 1000 ");
					}
						
				}
				
			}


			private void RemplisageAleatoireSymetrique() {
				
				Random rand = new Random (); 
			    for (int n = 0; n < nombreVille; n++) {
			      for (int j = 0; j <=n; j++) {
			    	  if(n==j) 
			    		  TableauDistance[n][j]=0;
			    	  	else {
			    	  		TableauDistance[n][j]=rand.nextInt(99)+1;
			    	  	}
			    	  	}
			    }
			    
			    for(int n=0;n<nombreVille;n++) {
			    	for(int j=0;j<nombreVille;j++) {
			    		if(TableauDistance[n][j]!=TableauDistance[j][n])
			    			TableauDistance[n][j]=TableauDistance[j][n];
			    	}
			    }
				
				
			}


			private void RemplisageAleatoireAsymetrique() {
				
				Random rand = new Random () ; 
			    for (int n = 0; n < nombreVille ; n++) {
			      for (int j = 0; j < nombreVille; j++) {
			    	  if(n==j) {
			    		  TableauDistance[n][j]=0;
			    	  }else {
			    		  TableauDistance[n][j] =  rand.nextInt (100);
			    	  }
			        
			      }
			    }
				
			}
			
		});
		
	}

	
	
	public void run()
	{
		vue.run();
	}
}
