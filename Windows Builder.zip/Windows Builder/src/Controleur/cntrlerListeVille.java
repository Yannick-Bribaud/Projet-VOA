package Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;
import Modele_tsp.GreedySolution;
import Modele_tsp.VOA;
import vue.AfficheDistanceVoa;
import vue.ListeDistances;
import vue.ListeVille;
import vue.VoaInterface;


public class cntrlerListeVille {
	
	ListeVille vue;
	GreedySolution model;
	VoaInterface vue_1;
	
	int compteur=0;
	String compt;
	int nbreVille;
	
	DefaultListModel<String>Maliste; 
	public cntrlerListeVille(ListeVille vue,GreedySolution model,VoaInterface vue_1) {
		
		this.vue = vue;
		this.model = model;
		this.vue_1 = vue_1;
		
		
		compteur = Integer.parseInt(vue_1.getTextFieldNombreVilleVOA().getText());
		compt = String.valueOf(compteur);
		vue.getLblAfficheNumVille().setText(compt);
		
		nbreVille = Integer.parseInt(vue_1.getTextFieldNombreVilleVOA().getText());
		GreedySolution.tab.clear();
		Maliste = new DefaultListModel<String>();
		Maliste.clear();
		
		AddactionListener();
		
	}

	private void AddactionListener() {
		
		vue.ecouteurBtnOk(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				try
				{
					clickOnbtnOk();
				} catch(IllegalArgumentException exception){
					
					vue.Message(exception.getMessage());
				}
				
			}
			
			
			private void clickOnbtnOk() {
				
				if(vue.getTextFieldListeVille().getText().isEmpty())
				{
					throw new IllegalArgumentException("veuiller saisir le nom d'une ville");
				}
				else
				{
					String nomVille=vue.getTextFieldListeVille().getText();
					GreedySolution.tab.add(nomVille);
					vue.getTextFieldListeVille().setText("");
					compteur = compteur-1;
					compt = String.valueOf(compteur);
					vue.getLblAfficheNumVille().setText(compt);
					
					if(compteur==0)
					{
						vue.fermer();
						affichageListeVilles();
						
						if(vue_1.getRdbtnAlatoire().isSelected() && vue_1.getRdbtnAsymetrie().isSelected())
						{
							MethodeRemplissageAleatoireAsymetrique();
								RemplissageTableau();
							
								AfficheDistanceVoa vue= new AfficheDistanceVoa();
								VOA model= new VOA(vue_1);
								ContrlerAfficheDistanceVOA control = new ContrlerAfficheDistanceVOA(vue,vue_1,model);
								control.run();
						}
						if(vue_1.getRdbtnAlatoire().isSelected() && vue_1.getRdbtnSymetrie().isSelected())
						{
							MethodeRemplissageAleatoireSymetrique();
								RemplissageTableau();
							
								AfficheDistanceVoa vue= new AfficheDistanceVoa();
								VOA model= new VOA(vue_1);
								ContrlerAfficheDistanceVOA control = new ContrlerAfficheDistanceVOA(vue,vue_1,model);
								control.run();
						}
						if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnAsymetrie().isSelected())
						{
							
							ListeDistances vue = new ListeDistances();
							VoaCntrler model=new VoaCntrler(vue_1); 
							CntrlerListeDistances controleur = new CntrlerListeDistances(vue,vue_1,model);
							controleur.run();	
						}
						
						if(vue_1.getRdbtnManuelle().isSelected() && vue_1.getRdbtnSymetrie().isSelected())
						{
							ListeDistances vue = new ListeDistances();
							VoaCntrler model=new VoaCntrler(vue_1); 
							CntrlerListeDistances controleur = new CntrlerListeDistances(vue,vue_1,model);
							controleur.run();	
						}
						
					}			 
				}
			}

			
			private void MethodeRemplissageAleatoireSymetrique() {
				
				AllocationMemoire();
				Random rand = new Random (); 
			    for (int n = 0; n < nbreVille; n++) {
			      for (int j = 0; j <=n; j++) {
			    	  if(n==j) 
			    		  VoaCntrler.a[n][j]=0;
			    	  	else {
			    	  		VoaCntrler.a[n][j]=rand.nextInt(99)+1;
			    	  	}
			    	  	}
			    }
			    
			    for(int n=0;n<nbreVille;n++) {
			    	for(int j=0;j<nbreVille;j++) {
			    		if(VoaCntrler.a[n][j]!=VoaCntrler.a[j][n])
			    			VoaCntrler.a[n][j]=VoaCntrler.a[j][n];
			    	}
			    }
				
			}


			private void MethodeRemplissageAleatoireAsymetrique() {
				
				AllocationMemoire();
				
				Random rand = new Random () ; 
			    for (int n = 0; n < nbreVille ; n++) {
			      for (int j = 0; j < nbreVille; j++) {
			    	  if(n==j) {
			    		  VoaCntrler.a[n][j]=0;
			    	  }else {
			    		  VoaCntrler.a[n][j] =  rand.nextInt (100);
			    	  }
			        
			      }
			    }
				
			}



			private void AllocationMemoire() {
				
				int nombreVille = Integer.parseInt(vue_1.getTextFieldNombreVilleVOA().getText());
				int nombreGeneration= Integer.parseInt(vue_1.getTextFieldNombreGenerationsVOA().getText());
				int nombrePopulation = Integer.parseInt(vue_1.getTextFieldNombrePopulationVOA().getText());
				
				VoaCntrler.tab2= new double[nombreVille];
				VoaCntrler.tab3= new int[nombreVille];
				VoaCntrler.T= new int[nombreVille];
				VoaCntrler.C0= new int[nombrePopulation];
				VoaCntrler.c= new int[nombrePopulation];
				VoaCntrler.matrix= new double[nombrePopulation][nombreVille];
				VoaCntrler.a= new int[nombreVille][nombreVille];
				VoaCntrler.matrixt= new double[nombreVille];
				VoaCntrler.matrixtt= new double[nombreVille];
				VoaCntrler.classe= new int[nombreVille];
				VoaCntrler.classe1= new int[nombreVille];
				VoaCntrler.t= new int[nombreVille];
				VoaCntrler.d= new int[nombrePopulation];
				VoaCntrler.tt=new int[nombreVille];
				VoaCntrler.tabmin=new int[nombreGeneration];
					
			}

			
			
			private void RemplissageTableau() {
				
				// Mon tableau
				DefaultTableModel model = (DefaultTableModel)vue_1.getMytable().getModel();
				model.setRowCount(0);
				int taille = GreedySolution.tab.size();
				taille = taille * taille;
				Object [] row =new Object [taille];
				
				for(int i=0; i<GreedySolution.tab.size();i++)
				{
					for(int j=0; j<GreedySolution.tab.size();j++)
					{
						row[0] = GreedySolution.tab.get(i);
						row[1] = GreedySolution.tab.get(j);
						row[2] =VoaCntrler.a[i][j];
						
						model.addRow(row);
					}			
				}
					
			}


			private void affichageListeVilles() {
				
				
				for(int i=0; i< GreedySolution.tab.size(); i++)
				{
					Maliste.addElement(GreedySolution.tab.get(i));
				}
				vue_1.getList().setModel(Maliste);			
			}
			
		});
			
	}
	
	
	public void run()
	{
		vue.run();
	}
	
	public void Dispose()
	{
		vue.fermer();
	}

}
