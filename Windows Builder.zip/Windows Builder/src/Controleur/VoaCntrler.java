package Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import Modele_tsp.GreedySolution;
import vue.ListeVille;
import vue.VoaInterface;

public class VoaCntrler {

	VoaInterface vue;
	/*
	 * static int f, s, n = 2, R, tab3[]; static double yy; static double val;
	 * public static int a[][]; static int classe1[]; static int ta[]; static int
	 * classe[]; static int x; static double tab2[], matrix[][],matrixt[],
	 * matrixtt[], tab[], T[], t[], tt[], C0[], d[], tabmin[];
	 * 
	 * static int[] c[]; static int ii,ind,verif,best,tabdis[],min =
	 * Integer.MAX_VALUE,indB,best1[],matrixV[][], tabSol[][],matrixVV[][], v =
	 * 0,ch; static double xx;
	 */
	

	static int  f,s,ii;


	public static int ind;


	static int verif;


	static int n;


	public static int best;


	static int tabdis[];


	public static int min = Integer.MAX_VALUE;


	public static int indB;
	public static int best1[];
	static int matrixV[][];
	static int tabSol[][];
	static int matrixVV[][];
	static int tab3 [];
	public static int a[][];
	static int classe1[];
	static int ta[];
	static int classe[];
	static int x;
	public static int v = 0;
	static int ch;
	static int C0[];
	static int c[];
	static int d[];
	public static int tabmin[];
	static int T[];
	static int t[];

	static int tt[];
	static double tab2[],xx,yy,val, matrix[][],  matrixt[], matrixtt[], tab[];
	public static List<Integer> TabDis = new ArrayList<>();
	
	int nombreVille;
	int nombreGeneration;
	int nombreR;
	int TaillePopulation;
	int nombreVirus;
	

	public VoaCntrler(VoaInterface vue) {
		this.vue = vue;
		
		addActionListener();

	}

	private void addActionListener() {
		vue.addEcouteurBtnOK(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ClickOnbtnOKVoA();
				} catch (IllegalArgumentException ex) {
					vue.Message(ex.getMessage());
				}
			}

			private void ClickOnbtnOKVoA() {
				
					if (vue.getTextFieldNombreVilleVOA().getText().isEmpty()
							|| vue.getTextFieldNombreGenerationsVOA().getText().isEmpty()
							|| vue.getTextFieldNombrePopulationVOA().getText().isEmpty()
							|| vue.getTextFieldNbreRVOA().getText().isEmpty()
							|| vue.getTextFieldNbreVirus().getText().isEmpty()) {
						
						throw new IllegalArgumentException("Veuillez remplir tous les champs");
					}
					
					if(!(vue.getRdbtnAsymetrie().isSelected() || vue.getRdbtnSymetrie().isSelected()))
					{
						throw new IllegalArgumentException("Veuillez choisir un Type remplissage des distances");
					}
					
					if (!(vue.getRdbtnAlatoire().isSelected() || vue.getRdbtnManuelle().isSelected())) {
						
						throw new IllegalArgumentException("Veuillez choisir un mode remplissage des distances");
						
					} else {
						
						nombreVille = Integer.parseInt(vue.getTextFieldNombreVilleVOA().getText());
						TaillePopulation = Integer.parseInt(vue.getTextFieldNombrePopulationVOA().getText());
						nombreR = Integer.parseInt(vue.getTextFieldNbreRVOA().getText());
						nombreVirus = Integer.parseInt(vue.getTextFieldNbreVirus().getText());
						int varTestVirus = Math.round((TaillePopulation * 3)/10);

						if (nombreVille <= 3 || nombreVille > 1000) {
							
							throw new IllegalArgumentException("Le nombre de ville doit �tre Sup�rieur � 3 et inf�rieur 1000");
						}
						if (nombreR > (nombreVille / 2)) {
							
							throw new IllegalArgumentException("Le nombre R doit �tre inf�rieur ou �gal a " + (nombreVille / 2) + "");
						}
						if(nombreVirus > TaillePopulation )
						{
							throw new IllegalArgumentException("Le nombre de virus doit etre inf�rieur a la taille de la population");
						}
						if(nombreVirus<=0 || nombreVirus>varTestVirus)
						{
							throw new IllegalArgumentException("Le nombre de virus doit �tre Sup�rieur 0 inf�rieur � "+ nombreVirus +"");
						}
						else {
							
							SaisieDesVilles();	
						}

					}
				}

			private void SaisieDesVilles() {
				
				ListeVille vueListe = new ListeVille();
				GreedySolution model = new GreedySolution();
				cntrlerListeVille controler = new cntrlerListeVille(vueListe, model, vue);
				controler.run();
			}

		});

	}

	public void run() {
		vue.run();
	}

}
