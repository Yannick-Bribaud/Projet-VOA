package Controleur;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import Modele_tsp.GreedySolution;
import vue.GreedySolutionInterface;
import vue.ListeDistances;
import vue.ResultatGreedy;


public class CntrlerDistanceGreedy {
	
		ListeDistances vue;
		GreedySolutionInterface vue_Greedy;
		greedySolutionCntrler model;
		
		int compteur;
		int compteur2;
		int compte;
		int distance;
		boolean choixManuelle;
		boolean choix;
		private ArrayList<Integer> TabStdin; 
		
	public CntrlerDistanceGreedy(ListeDistances vue,GreedySolutionInterface vue_Greedy,boolean choix,boolean choixManuelle) {
		
		this.vue = vue;
		this.vue_Greedy = vue_Greedy;
		this.choixManuelle= choixManuelle;
		this.choix = choix;
		
		TabStdin = new ArrayList<Integer>();
		
		compteur = 0;
		compteur2= 1;
		compte=0;
		distance=0;
		
		
		
		
		if(choix==false && choixManuelle==false)
		{
		vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
		vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compteur2));
		}
		else
		{
			vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
			vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compte));
		}
		
		AddactionLister();	
	}
	
	
	private void AddactionLister() {
		
		vue.EcouteurBtnOk(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try
				{
					ClickOnbtnOK();
						
				}catch(IllegalArgumentException ex)
				{
					vue.Message(ex.getMessage());
				}		
			}

			private void ClickOnbtnOK() {
				
				if(vue.getTextFieldDistanceVilles().getText().isEmpty())
				{
					throw new IllegalArgumentException("Entrez une valeur svp!!!");
				}
				
				//Manuelle Symetrique
				if(choix == false && choixManuelle == false)
				{
					
					if(compteur < GreedySolution.tabGreedy.size()-1)
					{
						vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compteur2));
						
						
						distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
						TabStdin.add(distance);
						
						compteur2++;
						if(compteur2== GreedySolution.tabGreedy.size())
						{
							compteur++;
							compteur2=compteur+1;
						}
						
					if(compteur==GreedySolution.tabGreedy.size()-1 )
						{
							compteur2=compteur;
							vue.fermerFenetre();
							TransferDistanceMatrice();
							
							int nbreVille = GreedySolution.tabGreedy.size();
							ResultatGreedy vue = new ResultatGreedy();
							CntrlrResultatGreedy control = new CntrlrResultatGreedy(vue,vue_Greedy,nbreVille);
							control.run();
						}
						
						vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compteur2));
						
						vue.getTextFieldDistanceVilles().setText("");	
					}
					
				}
				
				
				//manuelle asymetrique
				if(choix == false && choixManuelle == true)
				{	
					if(compteur < GreedySolution.tabGreedy.size())
					{	
						 vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
						vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compte));
						
		
						if(GreedySolution.tabGreedy.get(compte).equalsIgnoreCase(GreedySolution.tabGreedy.get(compteur)))
						{
							greedySolutionCntrler.TableauDistance[compteur][compte]=0;
							
							compte++;
							if(compte == GreedySolution.tabGreedy.size())
							{
								compteur++;
								compte=0;
							}
							
							if(compteur==GreedySolution.tabGreedy.size())
							{
								vue.fermerFenetre();
								int nbreVille = GreedySolution.tabGreedy.size();
								ResultatGreedy vue = new ResultatGreedy();
								CntrlrResultatGreedy control = new CntrlrResultatGreedy(vue,vue_Greedy,nbreVille);
								control.run();
							}
						
							vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compte));
							vue.getTextFieldDistanceVilles().setText("");			
						}
						else
						{
							if(vue.getTextFieldDistanceVilles().getText().isEmpty())
							{
								throw new IllegalArgumentException("Entrez une valeur svp!!!");
							}
							else
							{
								distance = Integer.parseInt(vue.getTextFieldDistanceVilles().getText());
								greedySolutionCntrler.TableauDistance[compteur][compte]=distance;
								
								compte++;
								
								if(compte == GreedySolution.tabGreedy.size())
								{
									compteur++;
									compte=0;
								}
								
								vue.getLblAfficheVille_1().setText(GreedySolution.tabGreedy.get(compteur));
								vue.getLblAfficheVille_2().setText(GreedySolution.tabGreedy.get(compte));
								vue.getTextFieldDistanceVilles().setText("");
								
							}
							
						}
							
					}
					else
					{
						vue.fermerFenetre();		
					}
				}	
			}


			private void TransferDistanceMatrice() {
				
				int taille = GreedySolution.tabGreedy.size();
				int index=0;
				for(int i=0; i<taille;i++)
				{
					for(int j=0; j<taille;j++)
					{
						if(i==j)
						{
							greedySolutionCntrler.TableauDistance[i][j]=0;
						}
						if(j<=i)
						{
							greedySolutionCntrler.TableauDistance[i][j]=greedySolutionCntrler.TableauDistance[j][i];
						}
						else
						{
							greedySolutionCntrler.TableauDistance[i][j]=TabStdin.get(index);
							index++;
						}
					}
				}
				
			}
			
		});
		
		
	}
	
	
	public void run()
	{
		vue.run();
	}

}
