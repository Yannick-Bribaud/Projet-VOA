package Controleur;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;

import Modele_tsp.GreedySolution;
import vue.GreedySolutionInterface;
import vue.ListeDistances;
import vue.ListeVille;
import vue.ResultatGreedy;


public class CntrlerListeVilleGreedy {
	
	ListeVille vue_1;
	GreedySolution model;
	GreedySolutionInterface vue;
	
	int compt=0;
	String nomVille;
	String nombreVille;
	Boolean choix;
	boolean ChoixManuelle;
	
	public CntrlerListeVilleGreedy(ListeVille vue_1,GreedySolutionInterface vue, int compteur,Boolean choix,boolean ChoixManuelle) {
		
		this.vue_1=vue_1;
		this.vue=vue;
		this.compt=compteur;
		this.choix = choix;
		this.ChoixManuelle = ChoixManuelle;
		
		nombreVille=String.valueOf(compt);
		vue_1.getLblAfficheNumVille().setText(nombreVille);
		GreedySolution.tabGreedy.clear();
		AddActionListener();
		
	}
	
	
	private void AddActionListener() {
		
		vue_1.EcouteurOkGreedy(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					ClickOnBtnOkGreedy();
					
				}catch(IllegalArgumentException exception) {
					
					vue_1.Messages(exception.getMessage());
				}
				
				
			}

			private void ClickOnBtnOkGreedy() {
				
				if(vue_1.getTextFieldListeVille().getText().isEmpty())
				{
					throw new IllegalArgumentException("Entrez le nom d'une ville svp");
				}
				else
				{
					nomVille = vue_1.getTextFieldListeVille().getText();
					GreedySolution.tabGreedy.add(nomVille);
					vue_1.getTextFieldListeVille().setText("");
					compt = compt-1;
					nombreVille = String.valueOf(compt);
					vue_1.getLblAfficheNumVille().setText(nombreVille);
					
					if(compt==0)
					{
						vue_1.fermer();
						
						
						if(choix==false && ChoixManuelle==true)
						{
							ListeDistances vue_1 = new ListeDistances();
							CntrlerDistanceGreedy controleur =new CntrlerDistanceGreedy(vue_1,vue,choix,ChoixManuelle);
							controleur.run();
						}
						
						if(choix==true && ChoixManuelle==true )
						{
							int nbreVille = GreedySolution.tabGreedy.size();
							ResultatGreedy vue0 = new ResultatGreedy();
							CntrlrResultatGreedy control = new CntrlrResultatGreedy(vue0,vue,nbreVille);
							control.run();	
						}
						else
						{
							if(choix==false && ChoixManuelle==false)
							{
								ListeDistances vue_1 = new ListeDistances();
								CntrlerDistanceGreedy controleur =new CntrlerDistanceGreedy(vue_1,vue,choix,ChoixManuelle);
								controleur.run();
							}
							
							if(choix==true && ChoixManuelle==false)
							{
								int nbreVille = GreedySolution.tabGreedy.size();
								ResultatGreedy vue0 = new ResultatGreedy();
								CntrlrResultatGreedy control = new CntrlrResultatGreedy(vue0,vue,nbreVille);
								control.run();
							}
					}
						
					}
				}
				
			}

			
		});
		
	}
	
	
	public void run()
	{
		vue_1.run();
	}
	

}
